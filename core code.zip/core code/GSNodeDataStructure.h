#ifndef GSNODEDATASTRUCTURE_H
#define GSNODEDATASTRUCTURE_H
#include "OpenMeshClarification.h"


struct GSNode
{
	MyMesh::VertexHandle tar_vh;
	MyMesh::VertexHandle vh[2];
	int tag ;
};

#endif