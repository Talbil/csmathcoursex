#include<cmath>
#include"NodeDataStructure.h"

void rotation_Matrix(fvector3& tar_normal,fvector3& reference_normal,Matrix& M);

void angle2vector(float theta,fvector3& tar_normal,fvector3& tar_vector)
{
	Matrix M;
	fvector3 reference_normal,reference_direction,reference_vector;
	for (int i = 0;i < 3;i++)
	{
		reference_direction[i] = 0;
		reference_normal[i] = 0;
	}
	reference_direction[0] = 1;
	reference_normal[1] = 1;
	reference_vector[0] = std::cos(theta);
	reference_vector[1] = 0;
	reference_vector[2] = std::sin(theta);
	rotation_Matrix(reference_normal,tar_normal,M);
	for (int i = 0;i < 3;i++)
	{
		tar_vector[i] = 0;
		for (int j = 0;j < 3;j++)
		{
			tar_vector[i] += M[i][j]*reference_vector[j];
		}
	}
}