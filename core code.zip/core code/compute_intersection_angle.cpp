#include<vector>
#include<cmath>
#include"NodeDataStructure.h"
#include"OpenMeshClarification.h"
#define PI 3.1415926
void rotation_Matrix(fvector3& tar_normal,fvector3& reference_normal,Matrix& M);
float abs_angle(fvector3& tar_vector,fvector3& tar_normal);
float compute_intersection_angle(fvector3& cross_vector,MyMesh::VertexHandle tarVH,std::vector<TNode>& AllNode)
{
	fvector3 tar_normal;
	TNode tarNode,reference_Node;
	std::vector<TNode>::iterator TVH;
	for( TVH = AllNode.begin();TVH != AllNode.end();++TVH)
	{
		if(TVH->mesh_vh == tarVH)
		{
			tarNode = *TVH;
			break;
		}
	}
	for (int i = 0;i < 3;i++)
	{
		tar_normal[i] = tarNode.node_normal[i];
	}
	float theta = abs_angle(cross_vector,tar_normal);
		
	
	while (theta > PI/4)
	{
		theta -= PI/2;
	}
	TVH->node_cross = theta;
	return theta;
}

float abs_angle(fvector3& tar_vector,fvector3& tar_normal)
{
	float theta;
	Matrix M;
	fvector3 reference_normal,reference_direction,tar_vector_rotated;
	for(int i = 0;i < 3;i++)
	{
		reference_direction[i] = 0;
		reference_normal[i] = 0;
	}
	reference_direction[0] = 1;
	reference_normal[1] = 1;
	rotation_Matrix(tar_normal,reference_normal,M);
	for (int i = 0;i < 3;i ++)
	{
		tar_vector_rotated[i] = 0;
		for (int j = 0;j < 3;j++)
		{
			tar_vector_rotated[i] += M[i][j]*tar_vector[j];
		}
	}
	float cosine_theta = 0,sine_theta = 0;
	for(int i = 0; i < 3;i++)
		cosine_theta += tar_vector_rotated[i]*reference_direction[i];
	sine_theta = (tar_vector_rotated[1]*reference_direction[2]-tar_vector_rotated[2]*reference_direction[1])*reference_normal[0]+(tar_vector_rotated[2]*reference_direction[0]-tar_vector_rotated[0]*reference_direction[2])*reference_normal[1]+(tar_vector_rotated[0]*reference_direction[1]-tar_vector_rotated[1]*reference_direction[0])*reference_normal[2];

	if(cosine_theta >= 0&&sine_theta >= 0)
		theta = acos(cosine_theta);
	else if(cosine_theta >=0 && sine_theta <0)
		theta = 2*PI-acos(cosine_theta);
	else if(cosine_theta < 0&& sine_theta >=0 )
		theta =PI -acos(-cosine_theta);
	else 
		theta = acos(-cosine_theta)+PI;
	return theta;
}