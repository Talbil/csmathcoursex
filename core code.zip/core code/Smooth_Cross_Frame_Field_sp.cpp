/*
#include<cmath>
#include<map>
#include<vector>
#include"NodeDataStructure.h"
#include"OpenMeshClarification.h"
const int iterator_max = 1000;
typedef std::vector<float> Coe_row;
typedef std::vector<Coe_row> Coe_Matrix;
float triangle_area(fvector3& P0,fvector3& P1,fvector3& P2);
float obj_f(Coe_Matrix& Coe_Ma,std::vector<float>& theta_array)
{
	float result = 0;
	int max_n = theta_array.size();
	for (int i = 0;i < max_n;i++)
	{
		for (int j = 0;j < max_n;j++)
		{
			result += Coe_Ma[i][j]*(1-cos(4*theta_array[i]-4*theta_array[j]))/2;
		}
	}
	return result;
}
void first_diff(MyMesh& mesh,std::vector<float>& diret_vector,std::vector<TNode>& AllNode,Coe_Matrix Coe_Ma)
{
	int nodenum = diret_vector.size();
	for (int i = 0;i < nodenum;i++)
	{
		MyMesh::VertexHandle tar_vh;
		for (MyMesh::VertexIter v_it = mesh.vertices_begin();v_it != mesh.vertices_end();v_it++)
		{
			if (v_it->idx() == i)
			{
				tar_vh = *v_it;
				break;
			}
		}
		if (!mesh.is_boundary((tar_vh)))
		{
			for (int j = 0;j < nodenum;j++)
			{
				diret_vector[i] += 2*Coe_Ma[i][j]*sin(4*AllNode[i].node_cross-4*AllNode[j].node_cross);
				diret_vector[i] += 2*Coe_Ma[j][i]*sin(4*AllNode[i].node_cross-4*AllNode[j].node_cross);
			}
		}
	}
}
float deviation_quant(std::vector<float> diret_vector)
{
	float result = 0;
	int max_num = diret_vector.size();
	for (int i = 0;i < max_num;i++)
	{
		if (diret_vector[i] < 0)
		{
			result -= diret_vector[i];
		}
		else
		{
			result += diret_vector[i];
		}
	}
	return result;
}
void Smooth_Cross_Frame_Field_sp(int numIterations,std::vector<TNode>& AllNode,MyMesh mesh,float kesi_threshold)
{
	Coe_Matrix Coe_Ma;
	float tmp_coe = 0;
	Coe_Ma.clear();
	for (int i = 0;i < (int)AllNode.size();i++)
	{
		Coe_row tmprow;
		tmprow.clear();
		for (int i = 0;i < (int)AllNode.size();i++)
		{
			tmprow.push_back(tmp_coe);
		}
		Coe_Ma.push_back(tmprow);
	}
	for (MyMesh::VertexIter v_it = mesh.vertices_begin();v_it != mesh.vertices_end();v_it++)
	{
		if (!mesh.is_boundary(*v_it))
		{
			for (MyMesh::VertexVertexIter vv_it = mesh.vv_iter(*v_it);vv_it.is_valid();vv_it++)
			{
				for (MyMesh::VertexVertexIter vv_it_1 = mesh.vv_iter(*vv_it);vv_it_1.is_valid();vv_it_1++)
				{
					for (MyMesh::VertexVertexIter vv_it_2 = mesh.vv_iter(*v_it);vv_it_2.is_valid();vv_it_2++)
					{
						if (*vv_it_1 == *vv_it_2)
						{
							fvector3 P0,P1,P2;
							float area;
							for (int i = 0;i < 3;i++)
							{
								P0[i] = mesh.point(*v_it)[i];
								P1[i] = mesh.point(*vv_it)[i];
								P2[i] = mesh.point(*vv_it_2)[i];
							}
							area = triangle_area(P0,P1,P2);
							Coe_Ma[v_it->idx()][vv_it->idx()] += area;
						}
					}
				}
			}
		}
	}
	std::vector<float> direct_vector,variable_vec;
	direct_vector.clear();
	variable_vec.clear();
	float tmp = 0;
	int max_num = AllNode.size();
	for (int i = 0;i < max_num;i++)
	{
		direct_vector.push_back(tmp);
		variable_vec.push_back(AllNode[i].node_cross);
	}
	first_diff(mesh,direct_vector,AllNode,Coe_Ma);
	float deviation_q = deviation_quant(direct_vector);
	int iterator_time = 0;
	while (iterator_time < 1000)//��Ϊ��ͬ����ͬ������������ʱ�Ȳ����Ǽ�һ��threshold-kesi����Ӧ���Ǹ�������ص�
	{
		for (int i = 0;i < max_num;i++)
		{

		}
	}
}*/