#include<dlib/optimization.h>
#include<cmath>
#include<ctime>
#include<cstdlib>
#include<iostream>
#include<vector>
#include"OpenMeshClarification.h"
#include"NodeDataStructure.h"
#define eps 0.00001

//#include"QuadMesh.h"
#include"NodeDataStructure.h"
using namespace dlib;
float triangle_area(fvector3& P0,fvector3& P1,fvector3& P2);
typedef matrix<double,0,1> column_vec;
column_vec ambient_theta;
struct MyData
{
	float omiga;
	float node_cross;
};
void initial_theta_1(TNode tarNode,std::vector<TNode>& AllNode,MyMesh mesh)
{
	std::vector<MyData> MyArray;
	MyData tmpData;
	float distance;
	for (OP_Mesh::VertexVertexIter vv_it = mesh.vv_iter(tarNode.mesh_vh);vv_it;vv_it++)
	{
		distance = 0;
		for (std::vector<TNode>::iterator T_it = AllNode.begin();T_it != AllNode.end();T_it++)
		{
			if (T_it->mesh_vh == vv_it.handle())
			{
				tmpData.node_cross = T_it->node_cross;
				for (int i = 0;i < 3;i++)
				{
					distance += (mesh.point(T_it->mesh_vh)[i]-mesh.point(tarNode.mesh_vh)[i])*(mesh.point(T_it->mesh_vh)[i]-mesh.point(tarNode.mesh_vh)[i]);
				}
				distance = std::sqrt(distance);
	

				OP_Mesh::VertexHandle vh_s[2];
				int counter_d = 0;
				for (OP_Mesh::VertexOHalfedgeIter voh_it_c = mesh.voh_iter(tarNode.mesh_vh);voh_it_c;voh_it_c++)
				{
					for (OP_Mesh::VertexOHalfedgeIter voh_it_r = mesh.voh_iter(vv_it.handle()); voh_it_r; voh_it_r++)
					{
						if (mesh.to_vertex_handle(voh_it_c.handle()) == mesh.to_vertex_handle(voh_it_r.handle()))
						{
							vh_s[counter_d] = mesh.to_vertex_handle(voh_it_c.handle());
							counter_d++;
							break;
						}
					}
					if (counter_d == 2)
					{
						break;
					}
				}
				fvector3 P1,P2,P3,P4;
				for (int t = 0;t < 3;t++)
				{
					P1[t] = mesh.point(tarNode.mesh_vh)[t];
					P2[t] = mesh.point(vv_it.handle())[t];
					P3[t] = mesh.point(vh_s[0])[t];
					P4[t] = mesh.point(vh_s[1])[t];
				}
				//tmpData.omiga = (triangle_area(P1,P2,P3)+triangle_area(P1,P2,P4))/(distance/100+T_it->d);
				tmpData.omiga = (triangle_area(P1,P2,P3)+triangle_area(P1,P2,P4));
				//tmpData.omiga = 1/(1.0*(distance/100+T_it->d));
				//tmpData.omiga = 1/distance;
				//tmpData.omiga = 1/(distance*(distance/100+T_it->d));
				//tmpData.omiga = (1/distance+3/(distance/100+T_it->d));
				MyArray.push_back(tmpData);
				break;
			}
		}
	}
	ambient_theta.set_size(2*MyArray.size());
	for(int i = 0;i < MyArray.size();i++)
	{
		ambient_theta(2*i) = MyArray[i].node_cross;
		ambient_theta(2*i+1) = MyArray[i].omiga;
	}
}
float obj_fun_1(const column_vec& variant)
{
	float theta = variant(0);
	float result = 0;
	for (int i = 0;i < ambient_theta.size();i += 2)
	{
		result += ambient_theta(i+1)*(1-cos(4*theta-4*ambient_theta(i)))/2;
	}
	return result;
}
const column_vec fun_1_derivative_1(const column_vec& variant)
{ 
	float theta = variant(0);
	column_vec result(1);
	result(0) = 0;
	for(int i = 0;i < ambient_theta.size();i += 2)
	{
		result(0) += ambient_theta(i+1)*2*sin(4*theta-4*ambient_theta(i));
	}
	return  result;
}
const column_vec fun_1_derivative_2(const column_vec& variant)
{
	float theta = variant(0);
	column_vec result(1);
	result(0) = 0;
	for(int i = 0;i < ambient_theta.size();i+=2)
	{
		result(0) += ambient_theta(i+1)*8*cos(4*theta-4*ambient_theta(i));
	}
	return result;
}
float BFGS_Method(TNode tarNode,std::vector<TNode>& AllNode,MyMesh mesh)
{
	initial_theta_1(tarNode,AllNode,mesh);
	column_vec x(1);
	x(0) = tarNode.node_cross;
	find_min_box_constrained(bfgs_search_strategy(),objective_delta_stop_strategy(1e-15),obj_fun_1,fun_1_derivative_1,x,-M_PI/4,M_PI/4);
	for(std::vector<TNode>::iterator T_it = AllNode.begin();T_it != AllNode.end();T_it++)
	{
		if(T_it->mesh_vh == tarNode.mesh_vh)
		{
			T_it->node_cross = x;
			break;
		}
	}
	return x(0);
}
/*float BFGS_Method_1(TNode tarNode,std::vector<TNode>& AllNode,OP_Mesh mesh)
{
	initial_theta_1(tarNode,AllNode,mesh);
	column_vec x(1);
	x(0) = tarNode.node_cross;
	find_min(bfgs_search_strategy(),objective_delta_stop_strategy(1e-5),obj_fun_1,fun_1_derivative_1,x,0);
	return x(0);
}*/