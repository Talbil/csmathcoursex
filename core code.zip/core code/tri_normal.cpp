#include<cmath>
#include"OpenMeshClarification.h"
#include"NodeDataStructure.h"

void tri_normal_vh(MyMesh::VertexHandle vh1,MyMesh::VertexHandle vh2,MyMesh::VertexHandle vh3,MyMesh mesh,fvector3& tri_normal)
{
	fvector3 P01,P02;
	for(int i = 0;i < 3;i++)
	{
		P01[i] = mesh.point(vh2)[i]-mesh.point(vh1)[i];
		P02[i] = mesh.point(vh3)[i]-mesh.point(vh1)[i];
	}
	tri_normal[0] = P01[1]*P02[2]-P01[2]*P02[1];
	tri_normal[1] = P01[2]*P02[0]-P01[0]*P02[2];
	tri_normal[2] = P01[0]*P02[1]-P01[1]*P02[0];
	float lenth = 0;
	for (int i = 0; i < 3;i++)
	{
		lenth += tri_normal[i]*tri_normal[i];
	}
	lenth = std::sqrt(lenth);
	for (int i = 0;i < 3;i++)
		tri_normal[i] /= lenth;
}
void tri_normal_p(fvector3& P0,fvector3& P1,fvector3& P2,fvector3& tri_normal)
{
	fvector3 P01,P02;
	for(int i = 0;i < 3;i++)
	{
		P01[i] = P1[i]-P0[i];
		P02[i] = P2[i]-P0[i];
	}
	tri_normal[0] = P01[1]*P02[2]-P01[2]*P02[1];
	tri_normal[1] = P01[2]*P02[0]-P01[0]*P02[2];
	tri_normal[2] = P01[0]*P02[1]-P01[1]*P02[0];
	float lenth = 0;
	for (int i = 0; i < 3;i++)
	{
		lenth += tri_normal[i]*tri_normal[i];
	}
	lenth = std::sqrt(lenth);
	for (int i = 0;i < 3;i++)
		tri_normal[i] /= lenth;
}