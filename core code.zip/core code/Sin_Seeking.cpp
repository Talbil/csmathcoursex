#include<vector>
#include"OpenMeshClarification.h"
#include"Singularity.h"
#include"NodeDataStructure.h"
int Contain_not_singularity(MyMesh& mesh,TNode_LIST& AllNode,MyMesh::FaceHandle tarfh);

void Sin_Seeking(MyMesh mesh,std::vector<TNode> AllNode,std::vector<Singularity>& singularity_vector)
{
	//
}