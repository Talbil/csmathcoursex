#include<vector>
#include<iostream>
#include"NodeDataStructure.h"
#include"OpenMeshClarification.h"
struct dN2N3
{
	float d;
	TNode* PNode2;
	TNode* PNode3;
};
float compute_d(TNode* pNode1,TNode* pNode2,TNode* pNode3,std::vector<TNode> MyVector,const MyMesh mesh);
void  compute_cross(TNode* pNode1,TNode* pNode2,TNode* pNode3,std::vector<TNode> MyVector,const MyMesh mesh);

void Node_Method(TNode* pTNode,MyMesh& mesh,std::vector<TNode*>& pTNode_List,std::vector<TNode>& AllNode)
{
	float d;
	TNode* pNode1;
	TNode* pNode2;
	TNode* pNode3;

	for(MyMesh::VertexVertexIter vv_it = mesh.vv_iter(pTNode->mesh_vh);vv_it.is_valid();++vv_it)
	{
		dN2N3 candidate;
		candidate.d = -1.0;
		//�������Ĵ�������� Node1 = AllNode.at(vv_it->idx());���棬��Ϊ��ʵ����������������ʱ�����Ǵ���
		for(std::vector<TNode>::iterator TVH = AllNode.begin();TVH != AllNode.end();++TVH)
		{
			if(*vv_it == TVH->mesh_vh)
			{
				pNode1 = &(*TVH);
				break;
			}
		}
		int tag = 0;
		for(std::vector<TNode*>::iterator T_it = pTNode_List.begin(); T_it != pTNode_List.end(); T_it++)
		{
			if(*T_it == pNode1)
			{
				tag = 1;
				break;
			}
		}
		if(pNode1->node_alive == false && tag == 0)//ԭ������û�еģ�Ϊ�˱����ظ��������ж�����
		{
			for(MyMesh::VertexFaceIter vf_it = mesh.vf_iter(*vv_it);vf_it.is_valid();++vf_it)
			{
				int tag3 = 0;
				//��Node1��Node2���и�ֵ
				for(MyMesh::FaceVertexIter fv_it = mesh.fv_iter(*vf_it);fv_it.is_valid();++fv_it)
				{
					if(tag3 == 1&& *fv_it != pNode1->mesh_vh )
					{
						for(std::vector<TNode>::iterator TVH = AllNode.begin();TVH != AllNode.end();++TVH)
						{
							if(*fv_it == TVH->mesh_vh)
							{
								pNode3 = &(*TVH);
								break;
							}
						}
					}
					else if(*fv_it != pNode1->mesh_vh)
					{
						tag3 = 1;
						for(std::vector<TNode>::iterator TVH = AllNode.begin();TVH != AllNode.end();++TVH)
						{
							if(*fv_it == TVH->mesh_vh)
							{
								pNode2 = &(*TVH);
								break;
							}
						}
					}
				}
				//Node1,Node2��ֵ����
				if(pNode2->node_alive == true&&pNode3->node_alive == true)
				{
					d = compute_d(pNode1,pNode2,pNode3,AllNode,mesh);
					if(candidate.d == -1.0||(candidate.d != -1.0&&candidate.d>d))
					{
						candidate.d = d;
						candidate.PNode2 = pNode2;
						candidate.PNode3 = pNode3;
					}
				}
		}
		

		if(candidate.d != -1.0)
		{
			pNode1->d=candidate.d;
			compute_cross(pNode1,candidate.PNode2,candidate.PNode3,AllNode,mesh);
			
			pTNode_List.push_back(pNode1);
		}

		}
	}
}