#include<vector>
#include<cmath>
#include"NodeDataStructure.h"
#include"OpenMeshClarification.h"
#define PI 3.1415926

/*
void  compute_cross(TNode* pNode1,TNode* pNode2,TNode* pNode3,std::vector<TNode> MyVector,const MyMesh mesh)
{
	float x1,x3,y1;
	fvector3 P23,P21;
	MyMesh::Point Point1,Point2,Point3;
	Point1 = mesh.point(pNode1->mesh_vh);
	Point2 = mesh.point(pNode2->mesh_vh);
	Point3 = mesh.point(pNode3->mesh_vh);
	for(int i = 0; i< 3;i++)
	{
		P23[i] = Point3[i]-Point2[i];
		P21[i] = Point1[i]-Point2[i];
	}
	x3 = 0;
	x1 = 0.0;
	y1 = 0.0;
	for(int i = 0;i < 3;++i)
	{
		x3 += P23[i]*P23[i];
		x1 += P23[i]*P21[i];
		y1 += P21[i]*P21[i]; 

	}
	x3 = std::sqrt(x3);
	x1 /= x3;
	y1 = std::sqrt(y1-x1*x1);
	float node_cross=pNode2->node_cross+x1*(pNode3->node_cross-pNode2->node_cross)/x3+y1*(pNode3->node_cross-pNode2->node_cross)/x3;
	while(!(node_cross <= PI/4&&node_cross > -PI/4))
	{
		if(node_cross > PI/4)
			node_cross -= PI/2;
		else if(node_cross <= -PI/4)
			node_cross += PI/2;
	}
	pNode1->node_cross = node_cross;
}*/


void tri_normal_vh(MyMesh::VertexHandle vh1,MyMesh::VertexHandle vh2,MyMesh::VertexHandle vh3,MyMesh mesh,fvector3& tri_normal);
void  compute_cross(TNode* pNode1,TNode* pNode2,TNode* pNode3,std::vector<TNode> MyVector,const MyMesh mesh)
{
	float testtag = 0;
	fvector3 f_normal;
	TNode* tmppNode2;
	TNode* tmppNode3;
	tri_normal_vh(pNode1->mesh_vh,pNode2->mesh_vh,pNode3->mesh_vh,mesh,f_normal);
	for (int i = 0;i < 3;i++)
	{
		testtag += f_normal[i]*(pNode1->node_normal[i]);
	}
	if(testtag < 0)
	{
		tmppNode2 = pNode3;
		tmppNode3 = pNode2;
	}
	else
	{
		tmppNode2 = pNode2;
		tmppNode3 = pNode3;
	}
	float x1 = 0,x2 = 0,y2 = 0;
	fvector3 P1,P2;
	for(int i = 0;i < 3;i++)
	{
		P1[i] = mesh.point(tmppNode2->mesh_vh)[i]-mesh.point(pNode1->mesh_vh)[i];
		P2[i] = mesh.point(tmppNode3->mesh_vh)[i]-mesh.point(pNode1->mesh_vh)[i];
	}
	for (int i = 0;i < 3;i++)
	{
		x1 += P1[i]*P1[i];
		x2 += P1[i]*P2[i];
		y2 += P2[i]*P2[i];
	}
	x1 = std::sqrt(x1);
	x2 /= x1;
	y2 = std::sqrt(y2-x2*x2);
	float a2,a3,b2,b3;
	a2 = 0;
	a3 = -1/x1;
	b2 = 1/y2;
	b3 = x2/(x1*y2);
	float A = b2*b3;
	float B = a3*a3+b3*b3;
	float delta_node_cross = tmppNode2->node_cross-tmppNode3->node_cross;
	while (delta_node_cross <= -PI/4||delta_node_cross > PI/4)
	{
		if(delta_node_cross <= -PI/4)
			delta_node_cross += PI/2;
		else if (delta_node_cross > PI/4)
			delta_node_cross -= PI/2;
	}
	float node_cross = A*delta_node_cross/B+tmppNode2->node_cross;
	while(node_cross <= -PI/4||node_cross > PI/4)
	{
		if (node_cross <= -PI/4)
		{
			node_cross += PI/2;
		}
		else if(node_cross > PI/4)
		{
			node_cross -= PI/2;
		}
	}
	pNode1->node_cross = node_cross;
}