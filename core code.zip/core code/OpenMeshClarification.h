#ifndef OPENMESHCLARIFICATION_H
#define OPENMESHCLARIFICATION_H
#include<OpenMesh/Core/IO/MeshIO.hh>
#include<OpenMesh/Core/Mesh/PolyMesh_ArrayKernelT.hh>
typedef OpenMesh::PolyMesh_ArrayKernelT<> MyMesh;
struct MeshTraits : OpenMesh::DefaultTraits
{
	// let PPoint and Normal be a PVector of doubles
	typedef OpenMesh::Vec3d Point;
	typedef OpenMesh::Vec3d Normal;
	// already defined in OpenMesh::DefaultTraits
	HalfedgeAttributes(OpenMesh::Attributes::PrevHalfedge);
	VertexAttributes(OpenMesh::Attributes::Status);//Ҫdelete���γɷֱ�������⼸��ѡ��
	FaceAttributes(OpenMesh::Attributes::Status);
	EdgeAttributes(OpenMesh::Attributes::Status);
};
typedef OpenMesh::PolyMesh_ArrayKernelT<MeshTraits>  OP_Mesh;
#endif