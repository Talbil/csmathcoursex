#include<vector>
#include<cmath>
#include<cstdlib>
#include"NodeDataStructure.h"
#include"OpenMeshClarification.h"
#define eps 0.000001
#define PI 3.1415926
float compute_intersection_angle(fvector3& cross_vector,MyMesh::VertexHandle tarVH,std::vector<TNode>& AllNode);
void GenerateBoundaryCross(MyMesh& mesh,TNode_LIST& AllNode)
{
		for(std::vector<TNode>::iterator T_it = AllNode.begin();T_it != AllNode.end();++T_it)
		{
			if(mesh.is_boundary(T_it->mesh_vh))
			{
				T_it->node_alive = true;
				MyMesh::VertexHandle from_vh,to_vh;
				int counter = 0;
				for(MyMesh::VertexIHalfedgeIter vih_it = mesh.vih_begin(T_it->mesh_vh);vih_it.is_valid();vih_it++)
				{
					if(mesh.is_boundary(*vih_it))
					{
						from_vh = mesh.from_vertex_handle(*vih_it);
						counter++;
					}
					else if(mesh.is_boundary(mesh.opposite_halfedge_handle(*vih_it)))
					{
						to_vh = mesh.from_vertex_handle(*vih_it);
					}
					if(counter == 2)
						break;
				}
				/*for(MyMesh::VertexVertexIter vv_it = mesh.vv_iter(T_it->mesh_vh); vv_it.is_valid();vv_it++)
				{
					if(mesh.is_boundary(*vv_it))
					{
						if(counter == 0)
							from_vh = *vv_it;
						else if(counter == 1)
							to_vh = *vv_it;
						counter++;
					}
					if(counter == 2)
						break;
				}*/
				fvector3 from_vector,to_vector,final_vector;
				float cosin_theta = 0,theta_c,from_lenth = 0,to_lenth = 0,final_lenth = 0;
				int n_c;
				for(int i = 0;i < 3;i++)
				{
					from_vector[i] = mesh.point(from_vh)[i]-mesh.point(T_it->mesh_vh)[i];
					to_vector[i] = mesh.point(to_vh)[i]-mesh.point(T_it->mesh_vh)[i];
					from_lenth += from_vector[i]*from_vector[i];
					to_lenth += to_vector[i]*to_vector[i];
				}
				from_lenth = std::sqrt(from_lenth);
				to_lenth = std::sqrt(to_lenth);
				for (int i = 0;i < 3;i++)
				{
					from_vector[i] /= from_lenth;
					to_vector[i] /= to_lenth;
					cosin_theta += from_vector[i]*to_vector[i];
					final_vector[i] = to_vector[i]-from_vector[i];
					final_lenth += final_vector[i]*final_vector[i];
				}
				if (cosin_theta >= -0.707106&&cosin_theta < 0.707106)
				//if (cosin_theta <= 0&&cosin_theta != -1)
					n_c = 1;
				else
					n_c = 0;
				if(final_lenth < eps && final_lenth > -eps)
				{
					for(int i = 0;i < 3;i++)
						final_vector[i] = to_vector[i];
					compute_intersection_angle(final_vector,T_it->mesh_vh,AllNode);
				}
				else
				{
					final_lenth = std::sqrt(final_lenth);
					for(int i = 0;i < 3;i++)
						final_vector[i] /= final_lenth;
					compute_intersection_angle(final_vector,T_it->mesh_vh,AllNode);
					if(n_c == 1)
					{
						if(T_it->node_cross <= 0)
							T_it->node_cross += PI/4;
						else
							T_it->node_cross -= PI/4;
					}
				}
			}
		}
		
		//���涼��ԭ��д�ĺ������������Ѿ����ԣ�ֻ����û�д���һЩ�����
	/*std::vector<TNode>::iterator tVH,tVH_end(AllNode.end());

		for(tVH = AllNode.begin();tVH != tVH_end;++tVH)
		{
			if(mesh.is_boundary(tVH->mesh_vh))
			{
				tVH->node_alive = true;
				float T1[3],T2[3];
				MyMesh::VertexHandle vf,vs,vt;
				OpenMesh::VertexHandle vh1_1,vh1_2,vh2_1,vh2_2;
				for(MyMesh::VertexOHalfedgeIter vo_it=mesh.voh_iter(tVH->mesh_vh);vo_it.is_valid();++vo_it)
				{  
					
					if(mesh.is_boundary(*vo_it))
					{
					    vh1_1=mesh.from_vertex_handle(*vo_it);
						vh1_2=mesh.to_vertex_handle(*vo_it);
						if(vh1_1 == tVH->mesh_vh)
							vf =vh1_2;
						else
							vf = vh1_1;
					}
					else if(mesh.is_boundary(mesh.opposite_halfedge_handle(*vo_it)))
					{
						 vh2_1=mesh.to_vertex_handle(*vo_it);
						 vh2_2=mesh.from_vertex_handle(*vo_it);
					
						 if(vh2_1 == tVH->mesh_vh)
							 vt = vh2_2;
						 else
							 vt = vh2_1;
					}
					
					else
						continue;

				}
				if(vt.idx() < vf.idx())
				{
					vs = vt;
					vt = vf;
					vf = vs;
				}
				vs = tVH->mesh_vh;
				for(int i = 0;i < 3; i++)
				{
					T1[i] = mesh.point(vs)[i]-mesh.point(vf)[i];
					T2[i] = mesh.point(vt)[i]-mesh.point(vs)[i];
				}
				float len;
				len=std::sqrt(T1[0]*T1[0]+T1[1]*T1[1]+T1[2]*T1[2]);
				for(int i=0;i<3;i++)
					T1[i]/=len;
				len=std::sqrt(T2[0]*T2[0]+T2[1]*T2[1]+T2[2]*T2[2]);
				for(int i=0;i<3;i++)
					T2[i]/=len;
				



				float tag=0;
				for(int i=0;i<3;i++)
					tag+=T1[i]*T2[i];
				if(tag<=0)
					continue;

				float Tmp[3];
				len=0;
				for(int i=0;i<3;i++)
				{
					Tmp[i]=T1[i]-T2[i];
					len+=Tmp[i]*Tmp[i];
				}
				if(Tmp[0]==0&&Tmp[1]==0&&Tmp[2]==0)
				{
					compute_intersection_angle(T1,tVH->mesh_vh,AllNode);
				}		
				else//�����߲������ƽ��������������
				{
					len=std::sqrt(len);
					float M[3][3];
					for(int i=0;i<3;i++)
						M[i][0]=Tmp[i]/len;

					for(int i=0;i<3;i++)
						M[i][1]=tVH->node_normal[i];
					for(int i=0;i<3;i++)
						M[i][2]=T2[i];

					//-------------------------��M�������,�������MN�ĺ�������-----------				
					float MN[3][6];

					for(int i=0;i<3;i++)
						for(int j=0;j<3;j++)
							MN[i][j]=M[i][j];

					for(int i=0;i<3;i++)
						for(int j=0;j<3;j++)
						{
							if(i==j)
								MN[i][j+3]=1;
							else
								MN[i][j+3]=0;
						}
						int r;
						for(int i=0;i<3;i++){
							r=i;
							float absd=MN[i][i];
							if(absd<0)
								absd=-absd;
							for(int t=i;t<3;t++){
								float tabsd=MN[t][i];
								if(tabsd<0)
									tabsd=-tabsd;
								if(tabsd>absd){
									r=t;
									absd=tabsd;
								}
							}
							if(r!=i){
								float tmp[6];
								for(int s=0;s<6;s++)
									tmp[s]=MN[i][s];
								for(int s=0;s<6;s++)
									MN[i][s]=MN[r][s];
								for(int s=0;s<6;s++)
									MN[r][s]=tmp[s];
							}

							float celement=MN[i][i];
							for(int p=i;p<6;p++)
								MN[i][p]/=celement;
							if(i<2){
								for(int q=i+1;q<3;q++){
									for(int s=5;s>=i;s--)
										MN[q][s]-=MN[q][i]*MN[i][s];

								}

							}
						}
						float TMP;
						TMP=MN[1][2];
						for(int j=0;j<6;j++)
							MN[1][j]-=MN[2][j]*TMP;
						TMP=MN[0][2];
						for(int j=0;j<6;j++)
							MN[0][j]-=MN[1][j]*TMP;
						TMP=MN[0][1];
						for(int j=0;j<6;j++)
							MN[0][j]-=MN[1][j]*TMP;


						//---------------------------------------------------------
						//T*{T1-T2,N��T1}={0,0,1}==>Tδ��λ��ǰ������ĵ�����
						len=std::sqrt(MN[2][3]*MN[2][3]+MN[2][4]*MN[2][4]+MN[2][5]*MN[2][5]);
						fvector3 cross_vector;
						for(int i=0;i<3;i++)
							cross_vector[i]=MN[2][i+3]/len;
						compute_intersection_angle(cross_vector,tVH->mesh_vh,AllNode);
				}
			}
		}*/
}