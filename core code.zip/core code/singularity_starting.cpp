#include<vector>
#include<cmath>
#include"NodeDataStructure.h"
#include"OpenMeshClarification.h"
#include"Singularity.h"
#include"StreamNodeDataStructure.h"
#define PI 3.1415926
void tri_normal_vh(MyMesh::VertexHandle vh1,MyMesh::VertexHandle vh2,MyMesh::VertexHandle vh3,MyMesh mesh,fvector3& tri_normal);
void rotation_Matrix(fvector3& tar_normal,fvector3& reference_normal,Matrix& M);
StreamNode starting_mapping(StreamNode begin_Node,std::vector<Singularity>& singularity_vector,fvector3& V,MyMesh mesh,MyMesh::FaceHandle belongfh);
float abs_angle(fvector3& tar_vector,fvector3& tar_normal);
void angle2vector(float theta,fvector3& tar_normal,fvector3& tar_vector);
void next_triangle_fh(StreamNode& tar_node,MyMesh::FaceHandle beginfh,std::vector<TNode> AllNode,MyMesh mesh);
void singularity_starting(Singularity tarsingularity,std::vector<Singularity>& singularity_vector,std::vector<TNode>& AllNode,MyMesh& mesh,std::vector<StreamNode>& stream_vector)
{
	//
}