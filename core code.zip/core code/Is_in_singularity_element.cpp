#include<vector>
#include"NodeDataStructure.h"
#include"Singularity.h"
#include"OpenMeshClarification.h"
#include"StreamNodeDataStructure.h"

bool Is_in_singularity_element_start(StreamNode testNode,std::vector<Singularity> singularity_vector,MyMesh mesh)
{
	bool result = false;
	MyMesh::FaceHandle tarfh;
	int counter = 0;
	for(MyMesh::VertexFaceIter vf_it = mesh.vf_iter(testNode.vh[0]);vf_it.is_valid();vf_it++)
	{
		for(MyMesh::FaceVertexIter fv_it = mesh.fv_iter(*vf_it);fv_it.is_valid();fv_it++)
		{
			if (*fv_it == testNode.vh[1]&& *vf_it != testNode.fh)
			{
				tarfh = *vf_it;
				counter++;
				break;
			}
		}
		if(counter == 1)
			break;
	}
	for(std::vector<Singularity>::iterator S_it = singularity_vector.begin();S_it != singularity_vector.end();S_it++)
	{
		
		if(S_it->faceh == tarfh)
		{
			result = true;
			break;
		}
	}
	return result;
}
bool Is_in_singularity_element_trace(StreamNode testNode,std::vector<Singularity> singularity_vector,MyMesh mesh)
{
	bool result = false;
	MyMesh::FaceHandle tarfh;
	int counter = 0;
	
	for(std::vector<Singularity>::iterator S_it = singularity_vector.begin();S_it != singularity_vector.end();S_it++)
	{

		if(S_it->faceh == testNode.fh)
		{
			result = true;
			break;
		}
	}
	return result;
}