#ifndef NODEDATASTRUCTURE_H
#define NODEDATASTRUCTURE_H
#include<vector>
#include"OpenMeshClarification.h"
typedef float fvector3 [3];
typedef float Matrix [3][3];
struct TNode
{
//int mesh_index;
MyMesh::VertexHandle mesh_vh;
fvector3 nodeposition;
float node_cross;
fvector3 node_normal;
float d;
bool node_alive;
 bool operator<(const TNode& tar)const
 {
	 return mesh_vh.idx() <tar.mesh_vh.idx();
 }
};
typedef std::vector<TNode> TNode_LIST; 
#endif