#include<string>
#ifndef _QANDMTRANS_H
#define _QANDMTRANS_H
typedef float ValType;
struct Quat {
	ValType _v[4];//x, y, z, w

	/// Length of the quaternion = sqrt( vec . vec )
	ValType length() const
	{
		return sqrt( _v[0]*_v[0] + _v[1]*_v[1] + _v[2]*_v[2] + _v[3]*_v[3]);
	}

	/// Length of the quaternion = vec . vec
	ValType length2() const
	{
		return _v[0]*_v[0] + _v[1]*_v[1] + _v[2]*_v[2] + _v[3]*_v[3];
	}
};
struct Matrix {
public:
	ValType _mat[3][3];

};
Matrix multipMatrix(const Matrix & M1,const Matrix & M2 );
void Quat2Matrix(const Quat& q, Matrix& m);
void Matrix2Quat(const Matrix& m, Quat& q);
void printMatrix(const Matrix& r, std::string name);
void printQuat(const Quat& q, std::string name);
Matrix transforMatrix(Matrix M1,Matrix M2);
Quat findquat(const Quat &q1,const Quat &q2,const Quat* Array,int sizeofArray);
Quat multipQuat(const Quat& q1,const Quat& q2);
ValType distanceofQuat(const Quat& q1,const Quat& q2,Quat* Array,int sizeofArray);
ValType dotproduct(const Quat& q1,const Quat& q2);
void generateQua_Matrix(Matrix** Array,Quat** Q);
Quat interpolation(const Quat& q1,const Quat& q2,const ValType alpha,const ValType belta,Quat* Array,const int& sizeofArray=24);
Quat scalar_multip(const ValType d1,const Quat Q1);
Quat inverse_Quat(const Quat Q);
void accumulation_Quat(Quat& Q1,const Quat Q2);
#endif