#include<vector>
#include<cmath>
#include"Singularity.h"
#include"StreamNodeDataStructure.h"
#include"NodeDataStructure.h"
#include"OpenMeshClarification.h"
#include "GSNodeDataStructure.h"
#define PI 3.1415926
bool Is_in_singularity_element_trace(StreamNode testNode,std::vector<Singularity> singularity_vector,MyMesh mesh);
void rotation_Matrix(fvector3& tar_normal,fvector3& reference_normal,Matrix& M);
void tri_normal_vh(MyMesh::VertexHandle vh1,MyMesh::VertexHandle vh2,MyMesh::VertexHandle vh3,MyMesh mesh,fvector3& tri_normal);
StreamNode tracing_mapping(StreamNode begin_Node,TNode* pNodes,fvector3& V,MyMesh mesh,MyMesh::FaceHandle belongfh);
StreamNode tracing_mapping_sp(TNode* pNodes,fvector3& V,MyMesh mesh,MyMesh::FaceHandle belongfh);
void angle2vector(float theta,fvector3& tar_normal,fvector3& tar_vector);
float abs_angle(fvector3& tar_vector,fvector3& tar_normal);
bool Is_boundary_edge(MyMesh mesh,StreamNode tar_node);
void next_triangle_fh(StreamNode& tar_node,MyMesh::FaceHandle beginfh,std::vector<TNode> AllNode,MyMesh mesh);
void singularity_tracing(std::vector<std::vector<StreamNode>>& Separartrix,std::vector<StreamNode> stream_start_vector,std::vector<TNode> AllNode, MyMesh mesh ,std::vector<Singularity> singularity_vector,std::vector<GSNode> gsnode_vector)
{
	//
}

bool Is_boundary_edge(MyMesh mesh,StreamNode tar_node)
{
	MyMesh::VertexHandle vh1,vh2;
	vh1 = tar_node.vh[0];
	vh2 = tar_node.vh[1];
	for (MyMesh::VertexOHalfedgeIter voh_it = mesh.voh_iter(vh1);voh_it.is_valid();voh_it++)
	{	
		if (mesh.to_vertex_handle(*voh_it) == vh2&&(mesh.is_boundary(*voh_it)||mesh.is_boundary(mesh.opposite_halfedge_handle(*voh_it))))
		{
			return true;
		}
	}
	return false;
}