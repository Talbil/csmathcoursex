#include<iostream>
#include<cmath>
#include<string>
#include"qandmtrans.h"
using namespace std;

typedef float ValType;

struct Quat;
struct Matrix;

struct Quat;

struct Matrix;

Matrix multipMatrix(const Matrix & M1,const Matrix & M2 ){
	Matrix resultM;
	for(int i=0;i<3;i++)
		for(int j=0;j<3;j++)
			resultM._mat[i][j]=0;
	for(int i=0;i<3;i++)
		for(int j=0;j<3;j++)
			for(int k=0;k<3;k++)
				resultM._mat[i][j]+=M1._mat[i][k]*M2._mat[k][j];
	return resultM;

}
#define QX q._v[0]
#define QY q._v[1]
#define QZ q._v[2]
#define QW q._v[3]


void Quat2Matrix(const Quat& q, Matrix& m)
{
	ValType length2 = q.length2();
	if (fabs(length2) <= std::numeric_limits<ValType>::min())
	{
		m._mat[0][0] = 0.0; m._mat[1][0] = 0.0; m._mat[2][0] = 0.0;
		m._mat[0][1] = 0.0; m._mat[1][1] = 0.0; m._mat[2][1] = 0.0;
		m._mat[0][2] = 0.0; m._mat[1][2] = 0.0; m._mat[2][2] = 0.0;
	}
	else
	{
		ValType rlength2;
		// normalize quat if required.
		// We can avoid the expensive sqrt in this case since all 'coefficients' below are products of two q components.
		// That is a square of a square root, so it is possible to avoid that
		if (length2 != 1)
		{
			rlength2 = 2/length2;
		}
		else
		{
			rlength2 = 2.0;
		}

		// Source: Gamasutra, Rotating Objects Using Quaternions
		//
		//http://www.gamasutra.com/features/19980703/quaternions_01.htm

		ValType wx, wy, wz, xx, yy, yz, xy, xz, zz, x2, y2, z2;

		// calculate coefficients
		x2 = rlength2*QX;
		y2 = rlength2*QY;
		z2 = rlength2*QZ;

		xx = QX * x2;
		xy = QX * y2;
		xz = QX * z2;

		yy = QY * y2;
		yz = QY * z2;
		zz = QZ * z2;

		wx = QW * x2;
		wy = QW * y2;
		wz = QW * z2;

		// Note. Gamasutra gets the matrix assignments inverted, resulting
		// in left-handed rotations, which is contrary to OpenGL and OSG's 
		// methodology. The matrix assignment has been altered in the next
		// few lines of code to do the right thing.
		// Don Burns - Oct 13, 2001
		m._mat[0][0] = 1.0 - (yy + zz);
		m._mat[1][0] = xy - wz;
		m._mat[2][0] = xz + wy;


		m._mat[0][1] = xy + wz;
		m._mat[1][1] = 1.0 - (xx + zz);
		m._mat[2][1] = yz - wx;

		m._mat[0][2] = xz - wy;
		m._mat[1][2] = yz + wx;
		m._mat[2][2] = 1.0 - (xx + yy);
	}
}

void Matrix2Quat(const Matrix& m, Quat& q)
{
	ValType s;
	ValType tq[4];
	int    i, j;

	// Use tq to store the largest trace
	tq[0] = 1 + m._mat[0][0]+m._mat[1][1]+m._mat[2][2];
	tq[1] = 1 + m._mat[0][0]-m._mat[1][1]-m._mat[2][2];
	tq[2] = 1 - m._mat[0][0]+m._mat[1][1]-m._mat[2][2];
	tq[3] = 1 - m._mat[0][0]-m._mat[1][1]+m._mat[2][2];

	// Find the maximum (could also use stacked if's later)
	j = 0;
	for(i=1;i<4;i++) j = (tq[i]>tq[j])? i : j;

	// check the diagonal
	if (j==0)
	{
		/* perform instant calculation */
		QW = tq[0];
		QX = m._mat[1][2]-m._mat[2][1];
		QY = m._mat[2][0]-m._mat[0][2];
		QZ = m._mat[0][1]-m._mat[1][0];
	}
	else if (j==1)
	{
		QW = m._mat[1][2]-m._mat[2][1];
		QX = tq[1];
		QY = m._mat[0][1]+m._mat[1][0];
		QZ = m._mat[2][0]+m._mat[0][2];
	}
	else if (j==2)
	{
		QW = m._mat[2][0]-m._mat[0][2];
		QX = m._mat[0][1]+m._mat[1][0];
		QY = tq[2];
		QZ = m._mat[1][2]+m._mat[2][1];
	}
	else /* if (j==3) */
	{
		QW = m._mat[0][1]-m._mat[1][0];
		QX = m._mat[2][0]+m._mat[0][2];
		QY = m._mat[1][2]+m._mat[2][1];
		QZ = tq[3];
	}

	s = sqrt(0.25/tq[j]);
	QW *= s;
	QX *= s;
	QY *= s;
	QZ *= s;
}

void printMatrix(const Matrix& r, string name)
{
	cout<<"RotMat "<<name<<" = "<<endl;
	cout<<"\t"<<r._mat[0][0]<<" "<<r._mat[0][1]<<" "<<r._mat[0][2]<<endl;
	cout<<"\t"<<r._mat[1][0]<<" "<<r._mat[1][1]<<" "<<r._mat[1][2]<<endl;
	cout<<"\t"<<r._mat[2][0]<<" "<<r._mat[2][1]<<" "<<r._mat[2][2]<<endl;
	cout<<endl;
}

void printQuat(const Quat& q, string name)
{
	cout<<"Quat "<<name<<" = "<<endl;
	cout<<"\t"<<q._v[0]<<" "<<q._v[1]<<" "<<q._v[2]<<" "<<q._v[3]<<endl;
	cout<<endl;
}

Matrix transforMatrix(Matrix M1,Matrix M2){
	ValType MN[3][6];
	Matrix resultM;
	for(int i=0;i<3;i++)
		for(int j=0;j<3;j++)
			resultM._mat[i][j]=0;
	for(int i=0;i<3;i++)
		for(int j=0;j<3;j++)
			MN[i][j]=M2._mat[i][j];
	for(int i=0;i<3;i++)
		for(int j=0;j<3;j++){
			if(i==j)
				MN[i][j+3]=1;
			else
				MN[i][j+3]=0;
		}
		int r;
		for(int i=0;i<3;i++){
			r=i;

			ValType absd=MN[i][i];

			if(absd<0)
				absd=-absd;
			for(int t=i;t<3;t++){
				ValType tabsd=MN[t][i];
				if(tabsd<0)
					tabsd=-tabsd;
				if(tabsd>absd){
					r=t;
					absd=tabsd;

				}

			}
			if(r!=i){
				ValType tmp[6];
				for(int s=0;s<6;s++)
					tmp[s]=MN[i][s];
				for(int s=0;s<6;s++)
					MN[i][s]=MN[r][s];
				for(int s=0;s<6;s++)
					MN[r][s]=tmp[s];
			}

			ValType celement=MN[i][i];
			for(int p=i;p<6;p++)
				MN[i][p]/=celement;
			if(i<2){
				for(int q=i+1;q<3;q++){
					for(int s=5;s>=i;s--)
						MN[q][s]-=MN[q][i]*MN[i][s];

				}

			}
		}
		ValType TMP;
		TMP=MN[1][2];
			for(int j=0;j<6;j++)
				MN[1][j]-=MN[2][j]*TMP;
		TMP=MN[0][2];
		    for(int j=0;j<6;j++)
				MN[0][j]-=MN[1][j]*TMP;
		TMP=MN[0][1];
		    for(int j=0;j<6;j++)
			    MN[0][j]-=MN[1][j]*TMP;
		


		Matrix invN;
		for(int i=0;i<3;i++)
			for(int j=0;j<3;j++)
				invN._mat[i][j]=MN[i][j+3];
		for(int i=0;i<3;i++)
			for(int j=0;j<3;j++)
				for(int n=0;n<3;n++)
					resultM._mat[i][j]+=M1._mat[i][n]*invN._mat[n][j];
		
		printMatrix(resultM,"result_M");
		return resultM;
		

}

Quat findquat(const Quat &q1,const Quat &q2,const Quat* Array,int sizeofArray){
	Quat resultQ;
	ValType maxmium=0;
   Quat q3,qtmp;
   int tag;
   qtmp=q2;
   for(int i=0;i<3;i++)
	   qtmp._v[i]=-qtmp._v[i];
   q3=multipQuat(q1,qtmp);
   
   ValType abs;

	for(int i=0;i<sizeofArray;i++){
		abs=0;
		for(int j=0;j<4;j++)
			abs+=Array[i]._v[j]*q3._v[j];
		if(abs<0)
			abs=-abs;
		if(abs>maxmium){
			tag=i;
			maxmium=abs;

		}
	}
	for(int j=0;j<4;j++)
		resultQ._v[j]=Array[tag]._v[j];
	return resultQ;

}

Quat multipQuat(const Quat& q1,const Quat& q2){
	Quat resultQ;
	resultQ._v[0]=q1._v[3]*q2._v[0]+q1._v[0]*q2._v[3]+q1._v[2]*q2._v[1]-q1._v[1]*q2._v[2];
	resultQ._v[1]=q1._v[3]*q2._v[1]+q1._v[1]*q2._v[3]+q1._v[0]*q2._v[2]-q1._v[2]*q2._v[0];
	resultQ._v[2]=q1._v[3]*q2._v[2]+q1._v[2]*q2._v[3]+q1._v[1]*q2._v[0]-q1._v[0]*q2._v[1];
	resultQ._v[3]=q1._v[3]*q2._v[3]-q1._v[0]*q2._v[0]-q1._v[1]*q2._v[1]-q1._v[2]*q2._v[2];
	return resultQ;
}

ValType dotproduct(const Quat& q1,const Quat& q2){
	ValType resultdotpro;
	resultdotpro=q1._v[0]*q2._v[0]+q1._v[1]*q2._v[1]+q1._v[2]*q2._v[2]+q1._v[3]*q2._v[3];

	return resultdotpro;
}

ValType distanceofQuat(const Quat& q1,const Quat& q2,Quat* Array,int sizeofArray)
{
	ValType result;
	Quat q3,q4,g;
	g=findquat(q1,q2,Array,sizeofArray);
	for(int i=0;i<3;i++)
		q3._v[i]=-q2._v[i];
	q3._v[3]=q2._v[3];
	q4=multipQuat(q1,q3);
	result=dotproduct(g,q4);
	if(result<0)
		result=-result;
	result=1-result;
	return result;
}

void generateQua_Matrix(Matrix** Array,Quat** Q){
	
 //ofstream out("24Quat.csv");
/*Matrix  Array[24];
	for(int l=0;l<24;l++)
		for(int i=0;i<3;i++)
			for(int j=0;j<3;j++)
				
					Array[l]._mat[i][j]=0;
	int count=0;
	for(int i=0;i<3;i++)
		for(int j=0;j<3;j++){
			if(j!=i){
				for(int tag1=-1;tag1<2;tag1+=2)
					for(int tag2=-1;tag2<2;tag2+=2){
						int remainco;
						int k;
						for( k=0;k<3;k++){
							if(k!=i&&k!=j)
								remainco=k;
						}
						Array[count]._mat[i][0]=tag1;
						Array[count]._mat[j][1]=tag2;
						Array[count]._mat[remainco][2]=tag1*tag2;
						if(i>j)
							Array[count]._mat[remainco][2]=-Array[count]._mat[remainco][2];
						count++;
					}
			}
		}
					
		Quat Q[24];
		for(int l=0;l<24;l++)
			Matrix2Quat(Array[l],Q[l]);
		for(int i=0;i<24;i++){
			printMatrix(Array[i],"M");
			printQuat(Q[i],"Q");

		}
			
		Matrix M1,M2,M3,M4;
		Quat q1,q2,q3,q4;
		
		M1._mat[0][0] =0;
		M1._mat[0][1] = 0;
		M1._mat[0][2] = 0;

		M1._mat[1][0] = 0;
		M1._mat[1][1] = 0;
		M1._mat[1][2] = 0;

		M1._mat[2][0] = 0;
		M1._mat[2][1] = 0;
		M1._mat[2][2] = 1;
		
		M2._mat[0][0] = 0.5;
		M2._mat[0][1] = -0.866025;
		M2._mat[0][2] = 0;

		M2._mat[1][0] = 0.866025;
		M2._mat[1][1] = 0.5;
		M2._mat[1][2] = 0;
		
		M2._mat[2][0] = 0;
		M2._mat[2][1] = 0;
		 M2._mat[2][2] = 1;
		
		Matrix2Quat(M1,q1);
		Matrix2Quat(M2,q2);
		cout<<"-*-*-*-"<<endl;
		M3=transforMatrix(M1,M2);
		Matrix2Quat(M3,q3);
		printQuat(q1,"q1");
		printQuat(q2,"q2");
		printQuat(q3,"q3");
		q4=findquat(M1,M2,Q,24);
		printQuat(q4,"q4");
			
		  
		q4._v[0]=0;
		q4._v[1]=0;
		q4._v[0]=0;
		q4._v[0]=-1;

		Quat2Matrix(q4,M4);
		printMatrix(M4,"M4");
		
		
		
		printMatrix(M4,"M4");*/
	Matrix M_C;
	M_C._mat[0][0] =1.0;
	M_C._mat[0][1] = 0.0;
	M_C._mat[0][2] = 0.0;

	M_C._mat[1][0] = 0.0;
	M_C._mat[1][1] = 1.0;
	M_C._mat[1][2] = 0.0;

	M_C._mat[2][0] = 0.0;
	M_C._mat[2][1] = 0.0;
	M_C._mat[2][2] = 1.0;
	Matrix M_X;
	M_X._mat[0][0] = 1.0;
	M_X._mat[0][1] = 0.0;
	M_X._mat[0][2] = 0.0;

	M_X._mat[1][0] = 0.0;
	M_X._mat[1][1] = 0.0;
	M_X._mat[1][2] = -1.0;

	M_X._mat[2][0] = 0.0;
	M_X._mat[2][1] = 1.0;
	M_X._mat[2][2] = 0.0;
	Matrix M_Y;
	M_Y._mat[0][0] = 0.0;
	M_Y._mat[0][1] = 0.0;
	M_Y._mat[0][2] = -1.0;

	M_Y._mat[1][0] = 0.0;
	M_Y._mat[1][1] = 1.0;
	M_Y._mat[1][2] = 0.0;

	M_Y._mat[2][0] = 1.0;
	M_Y._mat[2][1] = 0.0;
	M_Y._mat[2][2] = 0.0;
	Matrix M_Z;
	M_Z._mat[0][0] =0.0;
	M_Z._mat[0][1] =-1.0;
	M_Z._mat[0][2] = 0.0;

	M_Z._mat[1][0] = 1.0;
	M_Z._mat[1][1] = 0.0;
	M_Z._mat[1][2] = 0.0;

	M_Z._mat[2][0] = 0.0;
	M_Z._mat[2][1] = 0.0;
	M_Z._mat[2][2] = 1.0;
	
	Matrix MArray[64];

	int tag=0;
	int count=0;
	for(int i=0;i<4;i++)
		for(int j=0;j<4;j++)
			for(int k=0;k<4;k++)
			{ 
				MArray[tag]=M_C;
			for(int tag_x=1;tag_x<=i;tag_x++)
				MArray[tag]=multipMatrix(MArray[tag],M_X);
			for(int tag_y=1;tag_y<=j;tag_y++)
				MArray[tag]=multipMatrix(MArray[tag],M_Y);
			for(int tag_z=1;tag_z<=k;tag_z++)
				MArray[tag]=multipMatrix(MArray[tag],M_Z);
			int tag_if=0;
			int tag_next;
			int tag_count=0;
			for(int p=0;p<count;p++){
				tag_next=0;
				for(int i=0;i<3;i++){
					for(int j=0;j<3;j++){
						if((*Array)[p]._mat[i][j]!=MArray[tag]._mat[i][j])
						{
						tag_count+=1;
						tag_next=1;
						break;
						}
					}
					if(tag_next==1)
						break;
				}
				}
			if(tag_count==count)
				tag_if=1;

			
			if(tag_if==1){
				for(int i=0;i<3;i++)
					for(int j=0;j<3;j++)
						(*Array)[count]._mat[i][j]=MArray[tag]._mat[i][j];
				count++;
			}
			tag++;
		}
			for(int i=0;i<24;i++)
				Matrix2Quat((*Array)[i],(*Q)[i]);
		
}

Quat interpolation(const Quat& q1,const Quat& q2,const ValType alpha,const ValType belta,Quat* Array,const int sizeofArray=24){
	Quat resultQ,g_m,tmp,g_m_q2,q1_iq2;
	ValType dotpro,len;
	g_m=findquat(q1,q2,Array,24);
	for(int i=0;i<3;i++)
		tmp._v[i]=-q2._v[i];
	
	tmp._v[4]=q2._v[4];
	q1_iq2=multipQuat(q1,tmp);
	dotpro=dotproduct(g_m,q1_iq2);
	if(dotpro<0){
		for(int i=0;i<4;i++)
			g_m._v[i]=-g_m._v[i];
	}
	g_m_q2=multipQuat(g_m,q2);
	for(int i=0;i<4;i++)
		resultQ._v[i]=alpha*q1._v[i]+belta*g_m_q2._v[i];
	len=resultQ.length();
	for(int i=0;i<4;i++)
		resultQ._v[i]/=len;
	return resultQ;
}

Quat scalar_multip(const ValType d1,const Quat Q1)
{
	Quat resultQ;
	for(int i=0;i<4;i++)
		resultQ._v[i]=d1*Q1._v[i];
    return resultQ;	
}

Quat inverse_Quat(const Quat Q)
{
	Quat resultQ;
	for(int i=0;i<3;i++)
		resultQ._v[i]=Q._v[i];
	resultQ._v[3]=Q._v[3];
	return resultQ;
}

void accumulation_Quat(Quat& Q1,const Quat Q2)
{
	for(int i=0;i<4;i++)
		Q1._v[i]+=Q2._v[i];
}

