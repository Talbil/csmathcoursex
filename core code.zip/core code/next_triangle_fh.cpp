#include<vector>
#include"OpenMeshClarification.h"
#include"NodeDataStructure.h"
#include"StreamNodeDataStructure.h"
#define PI 3.1415926
/*
struct TmpData
{
	float delta_theta;
	MyMesh::VertexHandle vh;
};*/

float abs_angle(fvector3& tar_vector,fvector3& tar_normal);
void angle2vector(float theta,fvector3& tar_normal,fvector3& tar_vector);
float triangle_area(fvector3& P0,fvector3& P1,fvector3& P2)
{
	fvector3 a,b;
	for (int i = 0;i < 3;i++)
	{
		a[i] = P1[i]-P0[i];
		b[i] = P2[i]-P0[i];
	}

	float result = (a[1]*b[2]-a[2]*b[1]+a[2]*b[0]-a[0]*b[2]+a[0]*b[1]-a[1]*b[0]);
	if (result < 0)
	{
		return -result;
	}
	else
	{
		return result;
	}
}
bool Is_in_triangle(MyMesh mesh,MyMesh::VertexHandle vh1,MyMesh::VertexHandle vh2,MyMesh::VertexHandle vh3,fvector3& innerPoint)
{
	float a,b;
	fvector3 P1,P2,P3;
	for (int i = 0;i < 3;i++)
	{
		P1[i] = mesh.point(vh1)[i];
		P2[i] = mesh.point(vh2)[i];
		P3[i] = mesh.point(vh3)[i];
	}
	a = triangle_area(P1,P2,P3);
	b = triangle_area(P2,P3,innerPoint)+triangle_area(P1,P3,innerPoint)+triangle_area(P1,P2,innerPoint);
	if (b > a)
	{
		return false;
	} 
	else
	{
		return true;
	}
	
}
void next_triangle_fh(StreamNode& tar_node,MyMesh::FaceHandle beginfh,std::vector<TNode> AllNode,MyMesh mesh)
{
	//if (tar_node.alph != 0&&tar_node.alph != 1)
	//{
		int counter;
		for (MyMesh::FaceFaceIter ff_it = mesh.ff_iter(beginfh);ff_it.is_valid();ff_it++)
		{
			counter = 0;
			for (MyMesh::FaceVertexIter fv_it = mesh.fv_iter(*ff_it);fv_it.is_valid();fv_it++)
			{
				if (*fv_it == tar_node.vh[0]||*fv_it == tar_node.vh[1])
				{
					counter++;
				}
				if (counter == 2&&*ff_it != beginfh)
				{
					tar_node.fh = *ff_it;
					break;
				}
			}
		}
	//������������һ��鱻ע�͵����ǳ��֣������ڶ����ϵ����������ͳһ���������Ƿǳ�����0��1��ֵ��ĳ����ֵ�����
	/*
	} 
		else 
		{
			MyMesh::VertexHandle tar_vh;
			if (tar_node.alph == 0)
				tar_vh = tar_node.vh[1];
			else
				tar_vh = tar_node.vh[0];
			TNode beginNode;
			float tar_theta;
			for (std::vector<TNode>::iterator T_it = AllNode.begin();T_it != AllNode.end();T_it++)
			{
				if (T_it->mesh_vh == tar_vh)
				{
					beginNode = *T_it;
					break;
				}
			}
	
			tar_theta = beginNode.node_cross;
			while ((tar_node.theta-tar_theta) >= PI/4)
			{
				tar_theta += PI/4;
			}
			if (tar_theta >= 2*PI)
			{
				tar_theta -= 2*PI;
			} 
			else if (tar_theta < 0)
			{
				tar_theta += 2*PI;
			}
			MyMesh::VertexVertexIter vv_it = mesh.vv_iter(beginNode.mesh_vh);
			float lenth,minlenth = 0;
			for (int i = 0;i < 3;i++)
			{
				minlenth += (mesh.point(beginNode.mesh_vh)[i]-mesh.point(*vv_it)[i])*(mesh.point(beginNode.mesh_vh)[i]-mesh.point(*vv_it)[i]);
			}
			for (;vv_it.is_valid();vv_it++)
			{
				lenth = 0;
				for (int i = 0;i < 3;i++)
				{
					lenth += (mesh.point(beginNode.mesh_vh)[i]-mesh.point(*vv_it)[i])*(mesh.point(beginNode.mesh_vh)[i]-mesh.point(*vv_it)[i]);
				}
				if (lenth < minlenth)
				{
					minlenth = lenth;
				}
			}
			minlenth = std::sqrt(minlenth)/10;
			fvector3 tar_vector,node_normal;
			for (int i = 0;i < 3;i++)
			{
				node_normal[i] = beginNode.node_normal[i];
			}
			angle2vector(tar_theta,node_normal,tar_vector);
			for (int i = 0;i < 3;i++)
			{
				tar_vector[i] *= minlenth;
			}
			fvector3 tar_location;
			for (int i = 0;i < 3;i++)
			{
				tar_location[i] = tar_vector[i]+tar_node.location[i];
			}
			for (MyMesh::VertexFaceIter vf_it = mesh.vf_iter(beginNode.mesh_vh);vf_it.is_valid();vf_it++)
			{
				MyMesh::VertexHandle vh[3];
				int counter = 0;
				for (MyMesh::FaceVertexIter fv_it = mesh.fv_iter(*vf_it);fv_it.is_valid();fv_it++)
				{
					vh[counter] = *fv_it;
					counter++;
				}
	
				if(Is_in_triangle(mesh,vh[0],vh[1],vh[2],tar_location))
				{
					tar_node.fh = *vf_it;
					break;
				}
			}*/
	
		/*
		for (int i = 0;i < 5;i++)
		{
			if ((beginNode.node_cross+PI*i/2-tar_node.theta) <= PI/4&&(beginNode.node_cross+PI*i/2-tar_node.theta) > -PI/4)
			{
				tar_theta = beginNode.node_cross+PI*i/2;
				break;
			}
		}
		while (tar_theta >= 2*PI||tar_theta < 0)
		{
			if (tar_theta >= 2*PI)
			{
				tar_theta -= 2*PI;
			} 
			else if (tar_theta < 0)
			{
				tar_theta += 2*PI;
			}
		}
		
		TmpData MinTwoVertex[2];
				MinTwoVertex[0].delta_theta = PI;
				MinTwoVertex[1].delta_theta = PI;
				float lenth;
				float tmptheta,c_theta;
				for (MyMesh::VertexVertexIter vv_it = mesh.vv_iter(tar_vh);vv_it.is_valid();vv_it++)
				{
					lenth = 0;
					fvector3 edge_v;
					for (int i = 0;i < 3;i++)
					{
						edge_v[i] = mesh.point(*vv_it)[i]-mesh.point(beginNode.mesh_vh)[i];
						lenth += edge_v[i]*edge_v[i];
					}
					lenth = std::sqrt(lenth);
					for (int i = 0;i < 3;i++)
					{
						edge_v[i] /= lenth;
					}
					fvector3 tar_normal;
					for (int i = 0;i < 3;i++)
					{
						tar_normal[i] = beginNode.node_normal[i];
					}
					tmptheta = abs_angle(edge_v,tar_normal);
					c_theta = tmptheta - tar_theta;
					while(c_theta < -PI||c_theta >= PI)
					{
						if (c_theta < -PI)
						{
							c_theta += 2*PI;
						}
						else
						{
							c_theta -= 2*PI;
						}
					}
					if (c_theta < 0)
					{
						c_theta = -c_theta;
					}
					if (c_theta < MinTwoVertex[0].delta_theta)
					{
						MinTwoVertex[0].vh = *vv_it;
						MinTwoVertex[0].delta_theta = c_theta;
					}
					else if (c_theta < MinTwoVertex[1].delta_theta)
					{
						MinTwoVertex[1].vh = *vv_it;
						MinTwoVertex[1].delta_theta = c_theta;
					}
				}
		
		for (MyMesh::VertexFaceIter vf_it = mesh.vf_iter(tar_vh);vf_it.is_valid();vf_it++)
		{
			int counter_1 = 0;
			for (MyMesh::FaceVertexIter fv_it = mesh.fv_iter(*vf_it);fv_it.is_valid();fv_it++)
			{
				if (*fv_it == MinTwoVertex[0].vh||*fv_it == MinTwoVertex[1].vh)
				{
					counter_1++;
				}
			}
			if (counter_1 == 2)
			{
				tar_node.fh = *vf_it;
				break;
			}
		}*/
	//}
}

