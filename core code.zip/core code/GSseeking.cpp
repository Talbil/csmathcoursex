#include <vector>
#include "OpenMeshClarification.h"
#include "GSNodeDataStructure.h"
#include "StreamNodeDataStructure.h"
#include "NodeDataStructure.h"
#define  PI 3.1415926
#define eps 0.00000001
#define eps1 0.001
void tri_normal_vh(MyMesh::VertexHandle vh1,MyMesh::VertexHandle vh2,MyMesh::VertexHandle vh3,MyMesh mesh,fvector3& tri_normal);
void angle2vector(float theta,fvector3& tar_normal,fvector3& tar_vector);
bool Is_in_triangle(MyMesh mesh,MyMesh::VertexHandle vh1,MyMesh::VertexHandle vh2,MyMesh::VertexHandle vh3,fvector3& innerPoint);
void next_triangle_fh(StreamNode& tar_node,MyMesh::FaceHandle beginfh,std::vector<TNode> AllNode,MyMesh mesh);
void GSseeking(MyMesh mesh,std::vector<GSNode>& GSNode_vector)
{
   int counter;
   MyMesh::VertexHandle vh1,vh2;
   GSNode tmpNode;
   for (MyMesh::VertexIter v_it = mesh.vertices_begin();v_it != mesh.vertices_end();v_it++)
   {
		counter = 0;
		if (mesh.is_boundary(*v_it))
		{
			for (MyMesh::VertexOHalfedgeIter voh_it = mesh.voh_iter(*v_it);voh_it.is_valid();voh_it++)
			{
				if (mesh.is_boundary(*voh_it))
				{
					counter++;
					vh1 = mesh.to_vertex_handle(*voh_it);
				}
				else if (mesh.is_boundary(mesh.opposite_halfedge_handle(*voh_it)))
				{
					counter++;
					vh2 = mesh.to_vertex_handle(*voh_it);
				}
				if (counter == 2)
				{
					break;
				}
			}
			if (counter == 2)
			{
				fvector3 edge_vector[2];
				float lenth[2];
				for (int t = 0;t < 3;t++)
				{
					edge_vector[0][t] = mesh.point(vh1)[t]-mesh.point(*v_it)[t];
					edge_vector[1][t] = mesh.point(vh2)[t]-mesh.point(*v_it)[t];
				}
				for (int p = 0;p < 2;p++)
				{
					lenth[p] = 0;
					for (int q = 0;q < 3;q++)
					{
						lenth[p] += edge_vector[p][q]*edge_vector[p][q];
					}
					lenth[p] = std::sqrt(lenth[p]);
					for (int q = 0;q < 3;q++)
					{
						edge_vector[p][q] /= lenth[p];
					}
				}
				float angle_cosin = 0;
				for (int p = 0;p < 3;p++)
				{
					angle_cosin += edge_vector[0][p]*edge_vector[1][p];
				}
				if (angle_cosin >= -0.8660254&&angle_cosin <= 0.96592589)//�ж��Ƿ�Ϊ�����������ݣ��������ĽǶȽ���15�ȵ�150��֮��
				{
					tmpNode.tar_vh = *v_it;
					tmpNode.vh[0] = vh1;
					tmpNode.vh[1] = vh2;
					tmpNode.tag = 0;
					GSNode_vector.push_back(tmpNode);
				}
			}
		}
	}
}
void GSNode2StreamNode(MyMesh mesh,std::vector<TNode> AllNode,GSNode& tar_GS,std::vector<StreamNode>& stream_start_vector)
{
	TNode tarNode;
	StreamNode start_node;
	fvector3 tar_normal,start_vector,edge_vecotr[2];
	float theta,inter_angle[2],lenth;
	for (std::vector<TNode>::iterator T_it = AllNode.begin();T_it != AllNode.end();T_it++)
	{
		if (T_it->mesh_vh == tar_GS.tar_vh)
		{
			tarNode = *T_it;
			break;
		}
	}
	for (int i = 0;i < 3;i++)
	{
		tar_normal[i] = tarNode.node_normal[i];
	}
	for (int i = 0;i < 4;i++)
	{
		theta = tarNode.node_cross + PI*i/2;
		angle2vector(theta,tar_normal,start_vector);
		for (int j = 0;j < 2;j++)
		{
			inter_angle[j] = 0;
			lenth = 0;
			for (int k = 0;k < 3;k++)
			{
				edge_vecotr[j][k] = mesh.point(tar_GS.vh[j])[k]-mesh.point(tar_GS.tar_vh)[k];
				lenth += edge_vecotr[j][k]*edge_vecotr[j][k];
			}
			lenth = std::sqrt(lenth);
			for (int k = 0;k < 3;k++)
			{
				edge_vecotr[j][k] /= lenth;
				inter_angle[j] += edge_vecotr[j][k]*start_vector[k];
			}
		}
		if ((inter_angle[0] < 0.8660254)&&(inter_angle[1] < 0.8660254))//�ж�Cross�ĸ�������ĳ�����Ƿ������Ҫ�����������������߽��н��Ƿ����30��
		{
			for (MyMesh::VertexFaceIter vf_it = mesh.vf_iter(tar_GS.tar_vh);vf_it.is_valid();vf_it++)//Ѱ�ҷ��������ķ���������ĸ�����������ε�Ԫ�ڣ����ýǶȹ�ϵ��
			{
				fvector3 fac_normal,fac_vector,tar_position,segement,edge_vector;
				MyMesh::VertexHandle vh[2];
				int counter = 0;
				float testtag = 0;
				
				for (MyMesh::FaceVertexIter fv_it = mesh.fv_iter(*vf_it);fv_it.is_valid();fv_it++)
				{
					if (*fv_it != tar_GS.tar_vh)
					{
						vh[counter] = *fv_it;
						counter++;
					}
				}

				//�����淨����������㷨�������Ƚϻ��ͳһ����ķ�����
				tri_normal_vh(tar_GS.tar_vh,vh[0],vh[1],mesh,fac_normal);
				for (int k = 0;k < 3;k++)
				{
					testtag += fac_normal[k]*tarNode.node_normal[k];
				}
				if (testtag < 0)
				{
					for (int k = 0;k < 3;k++)
					{
						fac_normal[k] = -fac_normal[k];
					}
				}


				angle2vector(theta,fac_normal,fac_vector);
				fvector3 edge_vector1,edge_vector2;
				float lenth1 = 0,lenth2 = 0;
				for (int p = 0;p < 3;p++)
				{
					edge_vector1[p] = mesh.point(vh[0])[p]-mesh.point(tar_GS.tar_vh)[p];
					lenth1 += edge_vector1[p]*edge_vector1[p];
				}
				for (int p = 0;p < 3;p++)
				{
					edge_vector2[p] = mesh.point(vh[1])[p]-mesh.point(tar_GS.tar_vh)[p];
					lenth2 += edge_vector2[p]*edge_vector2[p];
				}
				lenth1 = std::sqrt(lenth1);
				lenth2 = std::sqrt(lenth2);

				for (int p = 0;p < 3;p++)
				{
					edge_vector1[p] /= lenth1;
					edge_vector2[p] /= lenth2;
				}
				float alph1 = 0,alph2 = 0,alph3 = 0;
				for (int p = 0;p < 3;p++)
				{
					alph3 += edge_vector1[p]*edge_vector2[p];
					alph1 += edge_vector1[p]*fac_vector[p];
					alph2 += edge_vector2[p]*fac_vector[p];
				}
				alph1 = std::acos(alph1);
				alph2 = std::acos(alph2);
				alph3 = std::acos(alph3);
				if ((alph3-alph1-alph2) < eps1&&(alph3-alph1-alph2) > -eps1)//�����������theta(cross�ĸ������е�һ���Ƕȣ�����Ƕ���߽�Ƕȴ���ĳ���ض��Ƕ�)��ĳ��
					//�����������ڵ�ͶӰ���������߼нǺ��Ƿ������������ζ���Ƕ����ж��Ƿ����������ڲ�
				{
					float alph,a;
					StreamNode tmpNode;
					for (int t = 0;t < 3;t++)
					{
						segement[t] = mesh.point(vh[0])[t]-mesh.point(vh[1])[t];
						edge_vector[t] = mesh.point(vh[1])[t]-mesh.point(tar_GS.tar_vh)[t];
					}
				    a = segement[0]*fac_vector[1]-segement[1]*fac_vector[0];
					if (a > eps||a < -eps)
					{
						alph = (edge_vector[1]*fac_vector[0]-edge_vector[0]*fac_vector[1])/a;
					}
					else
					{
						a = segement[1]*fac_vector[2]-segement[2]*fac_vector[1];
						if (a > eps|| a < -eps)
						{
							alph = (edge_vector[2]*fac_vector[1]-edge_vector[1]*fac_vector[2])/a;
						}
						else
						{
							alph = (edge_vector[0]*fac_vector[2]-edge_vector[2]*fac_vector[0])/(segement[2]*fac_vector[0]-segement[0]*fac_vector[2]);
						}
					}
					if (alph > 0.9999)
					{
						alph = 0.9999;
					}
					else if (alph < 0.0001)
					{
						alph = 0.0001;
					}
					tmpNode.alph = alph;
					for (int t = 0;t < 3;t++)
					{
						tmpNode.location[t] = tmpNode.alph*mesh.point(vh[0])[t]+(1-tmpNode.alph)*mesh.point(vh[1])[t];
					}
					tar_GS.tag = 1;	
					tmpNode.tag = 2;
					tmpNode.theta = theta;
					tmpNode.vh[0] = vh[0];
					tmpNode.vh[1] = vh[1];
					next_triangle_fh(tmpNode,*vf_it,AllNode,mesh);
					stream_start_vector.push_back(tmpNode);
				}
			}
		}
	}
	
}