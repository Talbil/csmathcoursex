#include<vector>
#include<cmath>
#include"NodeDataStructure.h"
#include"OpenMeshClarification.h"
/*
float compute_d(TNode* pNode1,TNode* pNode2,TNode* pNode3,std::vector<TNode> MyVector,const MyMesh mesh)
{
	float resultd,x1,x3,y1;
	fvector3 P23,P21;
	MyMesh::Point Point1,Point2,Point3;
	Point1 = mesh.point(pNode1->mesh_vh);
	Point2 = mesh.point(pNode2->mesh_vh);
	Point3 = mesh.point(pNode3->mesh_vh);
	for(int i = 0; i< 3;i++)
	{
		P23[i] = Point3[i]-Point2[i];
		P21[i] = Point1[i]-Point2[i];
	}
	x3 = 0;
	x1 = 0;
	y1 = 0;
	for(int i = 0;i < 3;++i)
	{
		x3 += P23[i]*P23[i];
		x1 = x1 + P23[i]*P21[i];
		y1 = y1 + P21[i]*P21[i];
	}
	x3 = std::sqrt(x3);
	
	x1 /=x3;
	y1 = std::sqrt(y1-x1*x1);
	resultd = pNode2->d+x1*(pNode3->d-pNode2->d)/x3+y1*std::sqrt(1-(pNode3->d-pNode2->d)*(pNode3->d-pNode2->d)/(x3*x3));
	return resultd;
}*/

void tri_normal_vh(MyMesh::VertexHandle vh1,MyMesh::VertexHandle vh2,MyMesh::VertexHandle vh3,MyMesh mesh,fvector3& tri_normal);
float compute_d(TNode* pNode1,TNode* pNode2,TNode* pNode3,std::vector<TNode> MyVector,const MyMesh mesh)
{
	float testtag = 0;
	fvector3 f_normal;
	TNode* tmppNode2;
	TNode* tmppNode3;
	tri_normal_vh(pNode1->mesh_vh,pNode2->mesh_vh,pNode3->mesh_vh,mesh,f_normal);
	for (int i = 0;i < 3;i++)
	{
		testtag += f_normal[i]*(pNode1->node_normal[i]);
	}
	if(testtag < 0)
	{
		tmppNode2 = pNode3;
		tmppNode3 = pNode2;
	}
	else
	{
		tmppNode2 = pNode2;
		tmppNode3 = pNode3;
	}
	float x3 = 0,x1 = 0,y1 = 0;
	fvector3 P1,P2;
	for(int i = 0;i < 3;i++)
	{
		P1[i] = mesh.point(tmppNode3->mesh_vh)[i]-mesh.point(tmppNode2->mesh_vh)[i];
		P2[i] = mesh.point(pNode1->mesh_vh)[i]-mesh.point(tmppNode2->mesh_vh)[i];
	}
	for (int i = 0;i < 3;i++)
	{
		x3 += P1[i]*P1[i];
		x1 += P1[i]*P2[i];
		y1 += P2[i]*P2[i];
	}
	x3 = std::sqrt(x3);
	x1 /= x3;
	y1 = std::sqrt(y1-x1*x1);
	float resultd;
	resultd = pNode2->d+x1*(pNode3->d-pNode2->d)/x3+y1*std::sqrt(1-(pNode3->d-pNode2->d)*(pNode3->d-pNode2->d)/(x3*x3));
	return resultd;
}