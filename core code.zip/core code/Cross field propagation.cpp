#include"NodeDataStructure.h"
#include"OpenMeshClarification.h"
#include<vector>
#include<iostream>
#define PI 3.1415926
bool Less(const TNode* pNode1,const TNode* pNode2)
{
	return pNode1->d<pNode2->d;
}
void Node_Method(TNode* pTNode,MyMesh& mesh,std::vector<TNode*>& pTNode_List,std::vector<TNode>& AllNode);
void Cross_Field_Propragation(MyMesh& mesh,TNode_LIST& AllNode)
{
	std::vector<TNode*> narrow_band_list,alive_list;
	std::vector<TNode>::iterator tVH,tVH_end(AllNode.end());
	for( tVH = AllNode.begin();tVH != tVH_end;++tVH)
	{
		if(tVH->node_alive == true)
			alive_list.push_back(&(*tVH));
		
	}
	std::vector<TNode*>::iterator TVH, TVH_end(alive_list.end());
	for(TVH = alive_list.begin();TVH != TVH_end;++TVH)
		Node_Method(*TVH,mesh,narrow_band_list,AllNode);
	
	while(narrow_band_list.size() != 0)
	{
		std::sort(narrow_band_list.begin(),narrow_band_list.end(),Less);
		TNode* pTNode = narrow_band_list.at(0);
		narrow_band_list.erase(narrow_band_list.begin(),narrow_band_list.begin()+1);//ԭ������remove������������Ϊû���õ������������Ծ�ֱ����erase���������ܻ����
		pTNode->node_alive = true;

		Node_Method(pTNode,mesh,narrow_band_list,AllNode);
	}

}