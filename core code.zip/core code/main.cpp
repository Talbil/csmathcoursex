#include<iostream>
#include<ctime>
#include<cmath>
#include<vector>
#include<set>
#include<string>
#include<fstream>
#include"NodeDataStructure.h"
#include"OpenMeshClarification.h"
#include"Singularity.h"
#include"StreamNodeDataStructure.h"
#include "GSNodeDataStructure.h"
#pragma comment(lib,"ws2_32.lib")
//--------------OpenMesh
#define PI 3.1415926
typedef float fvector2 [2];

using std::string;
void GenerateBoundaryCross(MyMesh& mesh,TNode_LIST& AllNode);
void Cross_Field_Propragation(MyMesh& mesh,TNode_LIST& AllNode);
bool Less(const TNode* pNode1,const TNode* pNode2);
void Node_Method(TNode* pTNode,MyMesh& mesh,std::vector<TNode*> pTNode_List,std::vector<TNode>& AllNode);
void singularity_starting(Singularity tarsingularity,std::vector<Singularity>& singularity_vector,std::vector<TNode>& AllNode,MyMesh& mesh);
void rotation_Matrix(fvector3& tar_normal,fvector3& reference_normal,Matrix& M);
void Smooth_Cross_Frame_Field(int numIterations,std::vector<TNode>& AllNode,MyMesh mesh,float kesi_threshold);
void GSseeking(MyMesh mesh,std::vector<GSNode>& GSNode_vector);
void singularity_starting(Singularity tarsingularity,std::vector<Singularity>& singularity_vector,std::vector<TNode>& AllNode,MyMesh& mesh,std::vector<StreamNode>& stream_vector);
void GSNode2StreamNode(MyMesh mesh,std::vector<TNode> AllNode,GSNode& tar_GS,std::vector<StreamNode>& stream_start_vector);
void Sin_Seeking(MyMesh mesh,std::vector<TNode> AllNode,std::vector<Singularity>& singularity_vector);
void singularity_tracing(std::vector<std::vector<StreamNode>>& Separartrix,std::vector<StreamNode> stream_start_vector,std::vector<TNode> AllNode, MyMesh mesh ,std::vector<Singularity> singularity_vector,std::vector<GSNode> gsnode_vector);
void singularity_tracing_sp(std::vector<std::vector<StreamNode>>& Separartrix,std::vector<StreamNode> stream_start_vector,std::vector<TNode> AllNode, MyMesh mesh ,std::vector<Singularity> singularity_vector,std::vector<GSNode> gsnode_vector);
void singularity_tracing_sp1(std::vector<std::vector<StreamNode>>& Separartrix,std::vector<StreamNode> stream_start_vector,std::vector<TNode> AllNode, MyMesh mesh ,std::vector<Singularity> singularity_vector,std::vector<GSNode> gsnode_vector);
int main()
{
	string FileName("trimesh");
	MyMesh mesh;
	time_t t_start,t_end,t_between;
	int numIterations = 20;
	mesh.request_vertex_normals();
	if(!mesh.has_vertex_normals())
	{
		std::cerr<<"ERROR: Standard vertex property 'Normals' not available!"<<std::endl;
		return 1;
	}
	OpenMesh::IO::Options opt;
	string FileNameRead=FileName+".obj";
	if(!OpenMesh::IO::read_mesh(mesh,FileNameRead,opt))
	{
		std::cerr<<"Error: Cannot read mesh from input.obj!!"<<std::endl;
		return 1;
	}
	if(!opt.check(OpenMesh::IO::Options::VertexNormal))
	{
		mesh.request_face_normals();
		mesh.update_normals();
		mesh.release_face_normals();
	}
	
	t_start = time(NULL);
	TNode_LIST AllNode;
	TNode tmpMember;
	
	MyMesh::VertexIter v_it ,v_end(mesh.vertices_end());
    for(v_it=mesh.vertices_begin();v_it!=v_end;++v_it)
	{
		tmpMember.mesh_vh=*v_it;
		for(int k = 0; k < 3;k++)
		{
			tmpMember.node_normal[k] = mesh.normal(*v_it)[k];
			tmpMember.nodeposition[k] = mesh.point(*v_it)[k];
		}
			tmpMember.node_cross = (float)-PI/4.0;
			tmpMember.node_alive = false;
			tmpMember.d = 0.0;
		AllNode.push_back(tmpMember);
	}
	std::sort(AllNode.begin(),AllNode.end());
	GenerateBoundaryCross(mesh,AllNode);
	t_end = time(NULL);
	t_between = difftime(t_start,t_end);
    std::cout<<"Generated"<<t_between<<std::endl;
	t_start = time(NULL);
	Cross_Field_Propragation(mesh,AllNode);
	t_end = time(NULL);
	t_between = difftime(t_start,t_end);

	//=.=.=.=.=.=.==.=.=.=.=.=.=.
	/*for (std::vector<TNode>::iterator All_it = AllNode.begin();All_it != AllNode.end();All_it++)
	{
		if (!mesh.is_boundary(All_it->mesh_vh))
		{
			All_it->node_cross = 0;
		}
	}*/
	//=.=.=.=.=.=.=.=.=.=.=.=.=.==.=.=.=.=
	std::cout<<"CFP"<<t_between<<std::endl;
	float kesi_threshold = 0.001;
	t_start = time(NULL);
	Smooth_Cross_Frame_Field(numIterations,AllNode,mesh,kesi_threshold);
	t_end = time(NULL);
	t_between = difftime(t_start,t_end);
	std::cout<<"Smooth"<<t_between<<std::endl;
	//��ʼ��������Ϊ�����������Ϣ
	/*string FileNameAll=FileName+"AllMessage.obj";
	std::ofstream  fout(FileNameAll);
	for(std::vector<TNode>::iterator T_iter = AllNode.begin();T_iter != AllNode.end();++T_iter)
	{
		fout<<T_iter->mesh_vh<<" position: "<<T_iter->nodeposition[0]<<T_iter->nodeposition[1]<<T_iter->nodeposition[2]<<" d: "<<T_iter->d<<" nodecross: "<<T_iter->node_cross<<" nodenormal: "<<T_iter->node_normal[0]<<T_iter->node_normal[1]<<T_iter->node_normal[2]<<"node alive "<<T_iter->node_alive<<std::endl;
	}*/
	std::vector<Singularity> singularity_vector;
	std::vector<GSNode> gsnode_vector;
	Sin_Seeking(mesh,AllNode,singularity_vector);
	std::ofstream sin_out("F:\\2015-6-1 Paving\\Paving\\Singularity.txt");
	sin_out<<singularity_vector.size()<<std::endl;
	for (std::vector<Singularity>::iterator S_it_out = singularity_vector.begin();S_it_out != singularity_vector.end();S_it_out++)
	{
		for (int i = 0;i < 3;i++)
		{
			sin_out<<S_it_out->location[i]<<" ";
		}
		sin_out<<std::endl;
	}
	GSseeking(mesh,gsnode_vector);
	std::vector<StreamNode> stream_start_vector;
	for(std::vector<Singularity>::iterator S_it = singularity_vector.begin();S_it != singularity_vector.end();S_it++)
	{
		Singularity tarsingularity;
		tarsingularity = *S_it;
		singularity_starting(tarsingularity,singularity_vector,AllNode,mesh,stream_start_vector);
	}

	
	for (std::vector<GSNode>::iterator GS_it = gsnode_vector.begin();GS_it != gsnode_vector.end();GS_it++)
	{
		GSNode2StreamNode(mesh,AllNode,*GS_it,stream_start_vector);
	}
	std::vector<std::vector<StreamNode>> Separartrix;
	singularity_tracing(Separartrix,stream_start_vector,AllNode,mesh,singularity_vector,gsnode_vector);
	
	for(std::vector<Singularity>::iterator Sg_it = singularity_vector.begin();Sg_it != singularity_vector.end();++Sg_it)
	{
		MyMesh::Point newPoint;
		for(int i = 0;i < 3;i++)
			newPoint[i] = Sg_it->location[i];
		mesh.add_vertex(newPoint);
	}
	for(std::vector<StreamNode>::iterator S_it = stream_start_vector.begin();S_it != stream_start_vector.end();++S_it)
	{
		MyMesh::Point newPoint;
		for(int i = 0;i < 3;i++)
			newPoint[i] = S_it->location[i];
		mesh.add_vertex(newPoint);
	}
	std::ofstream out2("F:\\2015-6-1 Paving\\Paving\\separatrix.txt");
	out2<<Separartrix.size()<<std::endl;

	for (std::vector<std::vector<StreamNode>>::iterator T_it = Separartrix.begin();T_it != Separartrix.end();T_it++)
	{
		out2<<T_it->size()<<" ";
		for (std::vector<StreamNode>::iterator St_iter = T_it->begin();St_iter != T_it->end();St_iter++)
		{
			for (int i = 0;i < 3;i++)
			{
				out2<<St_iter->location[i]<<" ";
			}
		}
		out2<<std::endl;

	}
	int i = 0;
	for(std::vector<Singularity>::iterator S_it = singularity_vector.begin();S_it != singularity_vector.end();S_it++)
		i += S_it->singularity_index;
	std::cout<< i<<std::endl;
	


	std::ofstream outcross("F:\\2015-6-1 Paving\\Paving\\Cross_Field.obj");
	float t_mesh_lenth = 0;
	for (int i = 0;i < 3;i++)
	{
		t_mesh_lenth += (mesh.point(mesh.to_vertex_handle(mesh.halfedges_begin()))[i]-mesh.point(mesh.from_vertex_handle(mesh.halfedges_begin()))[i])*(mesh.point(mesh.to_vertex_handle(mesh.halfedges_begin()))[i]-mesh.point(mesh.from_vertex_handle(mesh.halfedges_begin()))[i]);
	}
	t_mesh_lenth = sqrt(t_mesh_lenth);
	Matrix M;
	fvector3 refer_normal;
	refer_normal[0] = 0;
	refer_normal[1] = 1;
	refer_normal[2] = 0;
	fvector3 vertex_normal,vector_former,vector_latter;
	outcross<<AllNode.size()<<std::endl;
	for(std::vector<TNode>::iterator T_it = AllNode.begin();T_it != AllNode.end();T_it++)
	{
		for(int i = 0;i < 3;i++)
			vertex_normal[i] = T_it->node_normal[i];
		rotation_Matrix(refer_normal,vertex_normal,M);
		float fai = T_it->node_cross;
		for(int i = 0;i < 4;i++)
		{
			fai += i*PI/2;
			vector_former[0] = cos(fai);
			vector_former[1] = 0;
			vector_former[2] = sin(fai);
			for(int j = 0;j < 3;j++)
			{
				vector_latter[j] = 0;
				for(int k = 0;k < 3;k++)
				{
					vector_latter[j] += M[j][k]*vector_former[k];
				}
			}
			for(int s = 0;s < 3;s++)
				outcross<<mesh.point(T_it->mesh_vh)[s]+0.4*t_mesh_lenth*vector_latter[s]<<" ";
		}
		outcross<<std::endl;
	}
	/*
	std::ofstream nout("node_normal.obj");
		fvector3 pend;
		for (MyMesh::VertexIter v_it = mesh.vertices_begin();v_it != mesh.vertices_end();v_it++)
		{
			for (int i = 0;i < 3;i++)
			{
				pend[i] = mesh.point(*v_it)[i]+4*mesh.normal(*v_it)[i];
				nout<<pend[i]<<" ";
			}
			nout<<std::endl;
	
		}
	*/
	
	if (!OpenMesh::IO::write_mesh(mesh, "addedvertexresult.obj")) 
	{
		std::cerr << "write error\n";
		exit(1);
	}
	

	system("pause");
	return 0;
}
