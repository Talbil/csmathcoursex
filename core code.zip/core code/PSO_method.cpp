#include<cmath>
#include<ctime>
#include<cstdlib>
#include<iostream>
#include<vector>
#include"OpenMeshClarification.h"
#include"NodeDataStructure.h"
#define eps 0.00001
#define PI 3.1415926
struct MyData
{
	float omiga;
	float node_cross;
};

float triangle_area(fvector3& P0,fvector3& P1,fvector3& P2);
float obj_fun(std::vector<MyData> MyArray,float theta)
{
	float result = 0;
	for(std::vector<MyData>::iterator M_it = MyArray.begin();M_it != MyArray.end();M_it++)
	{
		result += M_it->omiga*(1-cos(4*theta-4*M_it->node_cross))/2;
	}
	return result;
}
float first_derivative(std::vector<MyData> MyArray,float theta)
{
	float result = 0;
	for(std::vector<MyData>::iterator M_it = MyArray.begin();M_it != MyArray.end();M_it++)
	{
		result += M_it->omiga*2*sin(4*theta-4*M_it->node_cross);
	}
	return result;
}
float second_derivative(std::vector<MyData> MyArray,float theta)
{
	float result = 0;
	for(std::vector<MyData>::iterator M_it = MyArray.begin();M_it != MyArray.end();M_it++)
	{
		result += M_it->omiga*8*cos(4*theta-4*M_it->node_cross);
	}
	return result;
}
/*
float Newton_Method(TNode tarNode,std::vector<TNode>& AllNode,MyMesh mesh)
{
	std::vector<MyData> MyArray;
	MyData tmpData;
	MyMesh::VertexHandle vh[2];
	for(MyMesh::VertexVertexIter vv_it = mesh.vv_iter(tarNode.mesh_vh);vv_it.is_valid();vv_it++)
	{
		int counter = 0;
		for(MyMesh::VertexVertexIter vv_it1 = mesh.vv_iter(*vv_it);vv_it1.is_valid();vv_it1++)
		{
			
			for(MyMesh::VertexVertexIter vv_it2 = mesh.vv_iter(tarNode.mesh_vh);vv_it2.is_valid();vv_it2++)
			{
				std::cout<<*vv_it1<<" "<<*vv_it2<<std::endl;
				if(*vv_it1 == *vv_it2)
				{
					vh[counter++] = *vv_it1;
					break;
				}
			}
			if(counter == 3)
				break;
			
		}
		MyMesh::Point P0,P1,P2,P3;
		P0 = mesh.point(tarNode.mesh_vh);
		P1 = mesh.point(*vv_it);
		P2 = mesh.point(vh[0]);
		P3 = mesh.point(vh[1]);
		tmpData.omiga = cal_triangle_area(P0,P1,P2)+cal_triangle_area(P0,P1,P3);
		for(std::vector<TNode>::iterator T_it = AllNode.begin();T_it != AllNode.end();T_it++)
		{
			if(T_it->mesh_vh == *vv_it)
			{
				tmpData.node_cross = T_it->node_cross;
				break;
			}
		}
		MyArray.push_back(tmpData);
	}
	float x = tarNode.node_cross;
	float f_1,f_2;
	f_1 = first_derivative(MyArray,x);
	f_2 = second_derivative(MyArray,x);
	while(f_1/f_2 >= eps||f_1/f_2 <= -eps)
	{
		x -= f_1/f_2;
		while((x > PI/4||x <= -PI/4)&&f_2 > eps)
		{
			if(x > PI/4)
				x -= PI/2;
			else if(x <= -PI/4)
				x += PI/2;
		}
		f_1 = first_derivative(MyArray,x);
		f_2 = second_derivative(MyArray,x);
	}
	for(std::vector<TNode>::iterator T_it = AllNode.begin();T_it != AllNode.end();T_it++)
	{
		if(T_it->mesh_vh == tarNode.mesh_vh)
		{
			T_it->node_cross = x;
			
			break;
		}
	}
	return x;

}
*/
float PSO_Method(TNode tarNode,std::vector<TNode>& AllNode,MyMesh mesh)
{
	std::vector<MyData> MyArray;
	MyData tmpData;
	float distance;
	for (MyMesh::VertexVertexIter vv_it = mesh.vv_iter(tarNode.mesh_vh);vv_it.is_valid();vv_it++)
	{
		distance = 0;
		for (std::vector<TNode>::iterator T_it = AllNode.begin();T_it != AllNode.end();T_it++)
		{
			if(T_it->mesh_vh == *vv_it)
			{
				tmpData.node_cross = T_it->node_cross;
				for (int i = 0;i < 3;i++)
				{
					distance += (mesh.point(T_it->mesh_vh)[i]-mesh.point(tarNode.mesh_vh)[i])*(mesh.point(T_it->mesh_vh)[i]-mesh.point(tarNode.mesh_vh)[i]);
				}
				distance = std::sqrt(distance);
	

				MyMesh::VertexHandle vh_s[2];
				int counter_d = 0;
				for (MyMesh::VertexOHalfedgeIter voh_it_c = mesh.voh_iter(tarNode.mesh_vh);voh_it_c.is_valid();voh_it_c++)
				{
					for (MyMesh::VertexOHalfedgeIter voh_it_r = mesh.voh_iter(*vv_it);voh_it_r.is_valid();voh_it_r++)
					{
						if (mesh.to_vertex_handle(*voh_it_c) == mesh.to_vertex_handle(*voh_it_r))
						{
							vh_s[counter_d] = mesh.to_vertex_handle(*voh_it_c);
							counter_d++;
							break;
						}
					}
					if (counter_d == 2)
					{
						break;
					}
				}
				fvector3 P1,P2,P3,P4;
				for (int t = 0;t < 3;t++)
				{
					P1[t] = mesh.point(tarNode.mesh_vh)[t];
					P2[t] = mesh.point(*vv_it)[t];
					P3[t] = mesh.point(vh_s[0])[t];
					P4[t] = mesh.point(vh_s[1])[t];
				}
				tmpData.omiga = (triangle_area(P1,P2,P3)+triangle_area(P1,P2,P4))/(distance/100+T_it->d);
				//tmpData.omiga = (triangle_area(P1,P2,P3)+triangle_area(P1,P2,P4));
				//tmpData.omiga = 1/(1.0*(distance/100+T_it->d));
				//tmpData.omiga = 1/distance;
				//tmpData.omiga = 1/(distance*(distance/100+T_it->d));
				//tmpData.omiga = (1/distance+3/(distance/100+T_it->d));
				MyArray.push_back(tmpData);
				break;
			}
		}
	}
	//��Ŀ�꺯���ļ�ֵ�õ��ǻ���ţ�ٷ���ֻ����ļ�ֵ�������У��������ȫ��ţ�ٷ�(�Ż�����û���κ�Ч��)
	float x;
	/*
	float f1,f2;
	
	x = tarNode.node_cross;
	f1 = first_derivative(MyArray,x);
	f2 = second_derivative(MyArray,x);
	float pace = f1/f2;
	while(f2 > 0&&(pace > eps ||pace < -eps))
	{
		x -= pace;
	
		while(x <= -PI/4||x > PI/4)
		{
			if (x <= -PI/4)
				x += PI/4;
			else if (x > PI/4)
				x -= PI/4;
		}
		f1 = first_derivative(MyArray,x);
		f2 = second_derivative(MyArray,x);
		pace = f1/f2;
	}
	*/
	/*
	bool tag = true;
	float delta;
	float f;
	float alph,belta;
	while(tag)
	{
		f1 = first_derivative(MyArray,x);
		f2 = second_derivative(MyArray,x);
		if(f1 < eps||f1 > -eps)
		{
			if(f2 >= eps)
			{
				tag = false;
			}
			else
			{
				delta = eps;
				f = obj_fun(MyArray,x);
				do 
				{
					delta *= 2;
				} while (obj_fun(MyArray,x+delta) >= f);
				x += delta;
			}
		}
		else
		{
			belta = f2;
			if(belta <= -eps)
				belta = 1;
			alph = 1;
			while (obj_fun(MyArray,x-alph*f1/belta) > (f-alph*f1*f1/(4*belta)))
			{
				alph /= 2;
			}
			x -= alph*f1/belta;
		}
	}
	*/
	//�볢����������Ⱥ�㷨���������ֵ����������㷨���ܱ�֤���Ե�ȫ��������
	
	srand(time(0));
	float swarm[10];
	float tmp;
	for(int i = 0;i < 10;i++)
	{
		tmp = ((float)(rand()%10000))/10000;
		swarm[i] = tmp*PI/2-PI/4;
	}
	float kesi;
	float yite;
	float v_array[10];
	float p_array[10];
	float x_array[10];
	float p,f;
	p = swarm[0];
	p_array[0] = swarm[0];
	f = obj_fun(MyArray,p);
	for(int i = 0;i < 10;i++)
	{
		v_array[i] = 0;
		p_array[i] = swarm[i];
		x_array[i] = swarm[i];
		if(f > obj_fun(MyArray,swarm[i]))
		{
			p = swarm[i];
			f = obj_fun(MyArray,swarm[i]);
		}
	}
	int iteratornum = 100;
	int j = 0;
	float omiga;
	float delta = 1;
	while(j < iteratornum&&(delta > eps||delta < eps))
	{
		omiga = (0.5-0.2)*exp(1/(1+7*((float)j)/((float)iteratornum)));
		j++;
		srand(time(0));
		kesi = ((float)(rand()%10000))/10000;
		yite = ((float)(rand()%10000))/10000;
		for(int i = 0;i < 10;i++)
		{
			v_array[i] = omiga*v_array[i]+2*kesi*(p_array[i]-x_array[i])+2*yite*(p-x_array[i]);
			while(v_array[i] < 0||v_array[i] >= PI/2)
			{
				if(v_array[i] < 0)
					v_array[i] += PI/2;
				else if(v_array[i] >= PI/2)
					v_array[i] -= PI/2;
			}
			x_array[i] = x_array[i] +v_array[i];
			while (x_array[i] <= -PI/4||x_array[i] > PI/4)
			{
				if(x_array[i] <= -PI/4)
					x_array[i] += PI/2;
				else if(x_array[i] > PI/4)
					x_array[i] -= PI/2;
			}
			if(obj_fun(MyArray,x_array[i] )< obj_fun(MyArray,p_array[i]))
			{
				p_array[i] = x_array[i];
			}
			if(obj_fun(MyArray,x_array[i]) < f)
			{
				f = obj_fun(MyArray,x_array[i]);
				delta = p - x_array[i];
				p = x_array[i];
			}
		}
	}
	x = p;
	while(x <= -PI/4||x > PI/4)
	{
		if(x <= -PI/4)
			x += PI/2;
		else if(x > PI/4)
			x -= PI/4;
	}
	for(std::vector<TNode>::iterator T_it = AllNode.begin();T_it != AllNode.end();T_it++)
	{
		if(T_it->mesh_vh == tarNode.mesh_vh)
		{
			T_it->node_cross = x;
			break;
		}
	}
	return x;
}