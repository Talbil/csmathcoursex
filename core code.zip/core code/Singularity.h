#ifndef SINGULARITY_H
#define SINGULARITY_H
#include "OpenMeshClarification.h"

struct Singularity  
{
	OpenMesh::FaceHandle faceh;
	OpenMesh::VertexHandle vh[3];
	int singularity_index;
	float theta;
	MyMesh::Point location;
	float alph[3][2][2];
};
#endif