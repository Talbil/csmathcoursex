#include<cmath>
#include<vector>
#include"NodeDataStructure.h"
#include"OpenMeshClarification.h"
float PSO_Method(TNode tarNode,std::vector<TNode>& AllNode,MyMesh mesh);
float BFGS_Method(TNode tarNode,std::vector<TNode>& AllNode,MyMesh mesh);
float triangle_area(fvector3& P0,fvector3& P1,fvector3& P2);
void Smooth_Cross_Frame_Field(int numIterations,std::vector<TNode>& AllNode,MyMesh mesh,float kesi_threshold)
{
	std::vector<TNode> activeNodes,nextAcitveNodes;
	for(std::vector<TNode>::iterator T_it = AllNode.begin();T_it != AllNode.end();T_it++)
	{
		if(!mesh.is_boundary(T_it->mesh_vh))
		{
			activeNodes.push_back(*T_it);
		}
	}
	int iteration = 0;
	float theta_smoothed;
	while(iteration < numIterations&&activeNodes.size() != 0)
	{
		nextAcitveNodes.clear();
		for(std::vector<TNode>::iterator T_it =activeNodes.begin();T_it != activeNodes.end();++T_it)
		{
			theta_smoothed = BFGS_Method(*T_it,AllNode,mesh);
			T_it->node_cross = theta_smoothed;
			//theta_smoothed = PSO_Method(*T_it,AllNode,mesh);
			int tag1 = 0,tag2;
			for(MyMesh::VertexVertexIter vv_it = mesh.vv_iter(T_it->mesh_vh);vv_it.is_valid();vv_it++)
			{
				for(std::vector<TNode>::iterator T_it2 = activeNodes.begin();T_it2 != activeNodes.end();++T_it2)
				{
					if(T_it2->mesh_vh == *vv_it)
					{
						if((1-cos(4*theta_smoothed-4*T_it2->node_cross)/2) > kesi_threshold)
						{
							tag1 = 1;
							tag2 = 0;
							for(std::vector<TNode>::iterator T_it_next = nextAcitveNodes.begin();T_it_next!= nextAcitveNodes.end();T_it_next++)
							{
								if(T_it_next->mesh_vh == *vv_it)
								{
									tag2 = 1;
									break;
								}
							}
							if(tag2 == 0)
								nextAcitveNodes.push_back(*T_it2);
						}
						break;
					}
				}
			}
			if(tag1 == 1)
			{
				tag2 = 0;
				for(std::vector<TNode>::iterator T_it_next = nextAcitveNodes.begin();T_it_next!= nextAcitveNodes.end();T_it_next++)
				{
					if(T_it_next->mesh_vh == T_it->mesh_vh)
					{
						tag2 = 1;
						break;
					}
				}
				if(tag2 == 0)
					nextAcitveNodes.push_back(*T_it);

			}
		}
		activeNodes.clear();
		for(std::vector<TNode>::iterator T_it = nextAcitveNodes.begin();T_it != nextAcitveNodes.end();T_it++)
		{
			activeNodes.push_back(*T_it);
		}
		iteration++;
		std::cout<<iteration<<std::endl;
	}
}
/*struct MyData
{
	float omiga;
	float node_cross;
}
std::vector<std::vector<MyData>> MyArray;
void initial_theta_g(std::vector<TNode> activeNodes,std::vector<TNode>& AllNode,MyMesh mesh)
{

	MyData tmpData;
	float distance;
	TNode tarNode;
	for(std::vector<TNode>::iterator ac_it = activeNodes.begin();ac_it != activeNodes.end();ac_it++)
	{
		std::vector<MyData> single_Array;
		tarNode = *ac_it;
		for (OP_Mesh::VertexVertexIter vv_it = mesh.vv_iter(tarNode.mesh_vh);vv_it;vv_it++)
		{
			distance = 0;
			for (std::vector<TNode>::iterator T_it = AllNode.begin();T_it != AllNode.end();T_it++)
			{
				if (T_it->mesh_vh == vv_it.handle())
				{
					tmpData.node_cross = T_it->node_cross;
					for (int i = 0;i < 3;i++)
				    {
						distance += (mesh.point(T_it->mesh_vh)[i]-mesh.point(tarNode.mesh_vh)[i])*(mesh.point(T_it->mesh_vh)[i]-mesh.point(tarNode.mesh_vh)[i]);
					}
				    distance = std::sqrt(distance);
	

				    OP_Mesh::VertexHandle vh_s[2];
				    int counter_d = 0;
				    for (OP_Mesh::VertexOHalfedgeIter voh_it_c = mesh.voh_iter(tarNode.mesh_vh);voh_it_c;voh_it_c++)
				    {
						for (OP_Mesh::VertexOHalfedgeIter voh_it_r = mesh.voh_iter(vv_it.handle()); voh_it_r; voh_it_r++)
					    {
							if (mesh.to_vertex_handle(voh_it_c.handle()) == mesh.to_vertex_handle(voh_it_r.handle()))
						    {
								vh_s[counter_d] = mesh.to_vertex_handle(voh_it_c.handle());counter_d++;
								break;
						     }
					     }
						if (counter_d == 2)
					   {
						   break;
					   }
					}
					fvector3 P1,P2,P3,P4;
				    for (int t = 0;t < 3;t++)
					{
						P1[t] = mesh.point(tarNode.mesh_vh)[t];
					    P2[t] = mesh.point(vv_it.handle())[t];
					    P3[t] = mesh.point(vh_s[0])[t];
					    P4[t] = mesh.point(vh_s[1])[t];
				    }
				    //tmpData.omiga = (triangle_area(P1,P2,P3)+triangle_area(P1,P2,P4))/(distance/100+T_it->d);
				    tmpData.omiga = (triangle_area(P1,P2,P3)+triangle_area(P1,P2,P4));
				    //tmpData.omiga = 1/(1.0*(distance/100+T_it->d));
				    //tmpData.omiga = 1/distance;
				    //tmpData.omiga = 1/(distance*(distance/100+T_it->d));
				    //tmpData.omiga = (1/distance+3/(distance/100+T_it->d));
				    single_Array.push_back(tmpData);
				    break;
				}
			}
			MyArray.push_back(single_Array);
		}	
}
void Smooth_Cross_Frame_Field_LBFGS(int numIterations,std::vector<TNode>& AllNode,MyMesh mesh,float kesi_threshold)
{
	std::vector<TNode> activeNodes,boundaryNodes;
	for(std::vector<TNode>::iterator T_it = AllNode.begin();T_it != AllNode.end();T_it++)
	{
		if(!mesh.is_boundary(T_it->mesh_vh))
		{
			activeNodes.push_back(*T_it);
		}
		else
		{
			boundaryNodes.push_back(*T_it);
		}
	}
	
	
}*/