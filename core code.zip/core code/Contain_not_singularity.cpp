#include<vector>
#include"NodeDataStructure.h"
#include"OpenMeshClarification.h"
#define PI 3.1415926
#define e 0.0001
int Contain_not_singularity(MyMesh& mesh,TNode_LIST& AllNode,MyMesh::FaceHandle tarfh)
{
	TNode Nodes[3];
	int tag = 0;
	for(MyMesh::FaceHalfedgeIter fh_it = mesh.fh_iter(tarfh);fh_it.is_valid();++fh_it)
	{
		for(std::vector<TNode>::iterator T_it = AllNode.begin();T_it !=AllNode.end();T_it++)
		{
			if(T_it->mesh_vh == mesh.from_vertex_handle(*fh_it))
			{
				Nodes[tag++] = *T_it;
				break;
			}
		}
	}
	float rotation,sum_rotation = 0;
	rotation = Nodes[1].node_cross - Nodes[0].node_cross;
	if(rotation <= -PI/4.0)
		rotation += PI/2.0;
	else if(rotation > PI/4.0)
		rotation -= PI/2.0;
	else
		rotation = rotation;
	sum_rotation += rotation;

	rotation = Nodes[2].node_cross - Nodes[1].node_cross;
	if(rotation <= -PI/4.0)
		rotation += PI/2.0;
	else if(rotation > PI/4.0)
		rotation -= PI/2.0;
	else
		rotation = rotation;
	sum_rotation += rotation;

	rotation = Nodes[0].node_cross - Nodes[2].node_cross;
	if(rotation <= -PI/4.0)
		rotation += PI/2.0;
	else if(rotation > PI/4.0)
		rotation -= PI/2.0;
	else
		rotation = rotation;
	sum_rotation += rotation;

	sum_rotation /= (PI/2.0);
	int singularity_tag,clock_tag = 1;
	float junction_sine = 0.0;
	fvector3 v1,v2,v3;
	for(int i = 0;i < 3; i++)
	{
		v1[i] = mesh.point(Nodes[1].mesh_vh)[i]-mesh.point(Nodes[0].mesh_vh)[i];
		v2[i] = mesh.point(Nodes[2].mesh_vh)[i]-mesh.point(Nodes[0].mesh_vh)[i];
	}
	v3[0] = v1[1]*v2[2]-v1[2]*v2[1];
	v3[1] = v1[2]*v2[0]-v1[0]*v2[2];
	v3[2] = v1[0]*v2[1]-v1[1]*v2[0];
	for(int i =0 ;i < 3;++i)
		junction_sine += v3[i]*Nodes[0].node_normal[i];
	if(junction_sine < 0)
		clock_tag = -1;
	if(sum_rotation<1.0+e&&sum_rotation>1.0-e)
		singularity_tag = clock_tag;
	else if(sum_rotation<-1.0+e&&sum_rotation>-1.0-e)
		singularity_tag = -clock_tag;
	else 
		singularity_tag = 0;
	return singularity_tag;
} 