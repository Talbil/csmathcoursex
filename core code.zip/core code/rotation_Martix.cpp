#include<cmath>
#include"NodeDataStructure.h"
#define eps 0.000001
void rotation_Matrix(fvector3& tar_normal,fvector3& reference_normal,Matrix& M)
{
	for (int i = 0; i < 3; i++)
		for(int j = 0; j < 3; j++)
			M[i][j] = 0;
	//if(tar_normal[0] == reference_normal[0]&&tar_normal[1] == reference_normal[1]&&tar_normal[2] == reference_normal[2])
	if(((tar_normal[0]-reference_normal[0])<eps&&(tar_normal[0]-reference_normal[0])>-eps)&&((tar_normal[1]-reference_normal[1])<eps&&(tar_normal[1]-reference_normal[1])>-eps)&&((tar_normal[2]-reference_normal[2])<eps&&(tar_normal[2]-reference_normal[2])>-eps))
	{
		for(int i = 0; i < 3;i++)
			M[i][i] = 1;
	}
	//else if(tar_normal[0] == -reference_normal[0]&&tar_normal[1] ==-reference_normal[1]&&tar_normal[2] ==-reference_normal[2])
	else if(((tar_normal[0]+reference_normal[0])<eps&&(tar_normal[0]+reference_normal[0])>-eps)&&((tar_normal[1]+reference_normal[1])<eps&&(tar_normal[1]+reference_normal[1])>-eps)&&((tar_normal[2]+reference_normal[2])<eps&&(tar_normal[2]+reference_normal[2])>-eps))
	{
		M[0][0] = 1;
		M[1][1] = -1;
		M[2][2] = -1;
	}
	else
	{
		fvector3 u;
		u[0] = tar_normal[1]*reference_normal[2]-tar_normal[2]*reference_normal[1];
		u[1] = tar_normal[2]*reference_normal[0]-tar_normal[0]*reference_normal[2];
		u[2] = tar_normal[0]*reference_normal[1]-tar_normal[1]*reference_normal[0];
		float lenth = 0;
		for(int i = 0;i < 3;i++)
			lenth += u[i]*u[i];
		lenth = (float)std::sqrt(lenth);
		for(int i = 0;i < 3;i++)
			u[i]/=lenth;
		float miu = 0;
		for(int i = 0;i < 3;i++)
			miu += tar_normal[i]*reference_normal[i];
		miu = (float)std::acos((double) miu); 
		M[0][0] = cos(miu)+(1-cos(miu))*u[0]*u[0];
		M[0][1] = (1-cos(miu))*u[0]*u[1]-sin(miu)*u[2];
		M[0][2] = (1-cos(miu))*u[0]*u[2]+sin(miu)*u[1];
		M[1][0] = (1-cos(miu))*u[1]*u[0]+sin(miu)*u[2];
		M[1][1] = cos(miu)+(1-cos(miu))*u[1]*u[1];
		M[1][2] = (1-cos(miu))*u[1]*u[2]-sin(miu)*u[0];
		M[2][0] = (1-cos(miu))*u[2]*u[0]-sin(miu)*u[1];
		M[2][1] = (1-cos(miu))*u[2]*u[1]+sin(miu)*u[0];
		M[2][2] = cos(miu)+(1-cos(miu))*u[2]*u[2];
	}
}

