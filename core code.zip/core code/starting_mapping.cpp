#include<vector>
#include<iostream>
#include"Singularity.h"
#include"OpenMeshClarification.h"
#include"NodeDataStructure.h"
#include"StreamNodeDataStructure.h"
#define eps 0.000001
StreamNode starting_mapping(StreamNode begin_Node,std::vector<Singularity>& singularity_vector,fvector3& V,MyMesh mesh,MyMesh::FaceHandle belongfh)
{
    //
}